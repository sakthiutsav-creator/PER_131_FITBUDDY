import fs from 'fs';
import path from 'path';
import { UserRecord, DashboardStats } from '../src/types.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'fitbuddy_db.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function readDb(): Record<string, UserRecord> {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const initial = getSeedData();
      fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf-8');
      return initial;
    }
    const content = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(content);
  } catch (err) {
    console.error('Error reading database file:', err);
    return {};
  }
}

function writeDb(data: Record<string, UserRecord>): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing database file:', err);
    throw err;
  }
}

export function getAllUsers(): UserRecord[] {
  const db = readDb();
  return Object.values(db).sort((a, b) => {
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });
}

export function getUserById(userId: string): UserRecord | null {
  const db = readDb();
  return db[userId] || null;
}

export function saveUserRecord(record: UserRecord): void {
  const db = readDb();
  db[record.userId] = record;
  writeDb(db);
}

export function deleteUserRecord(userId: string): boolean {
  const db = readDb();
  if (db[userId]) {
    delete db[userId];
    writeDb(db);
    return true;
  }
  return false;
}

export function getStats(): DashboardStats {
  const users = getAllUsers();
  const totalUsers = users.length;
  const updatedPlans = users.filter((u) => !!u.updatedPlan).length;
  const totalPlansGenerated = totalUsers + updatedPlans;
  const activeUsers = users.filter((u) => {
    const created = new Date(u.createdAt).getTime();
    // active in the last 30 days
    return Date.now() - created < 30 * 24 * 60 * 60 * 1000;
  }).length;

  return {
    totalUsers,
    totalPlansGenerated,
    updatedPlans,
    activeUsers: activeUsers || totalUsers,
  };
}

function getSeedData(): Record<string, UserRecord> {
  const user1: UserRecord = {
    userId: 'fit-marcus-77',
    name: 'Marcus Reed',
    age: 29,
    weight: 82,
    goal: 'Muscle Gain',
    intensity: 'High',
    experience: 'Intermediate',
    duration: '60 minutes',
    availableDays: '5 days',
    preferences: 'Gym access with barbell & dumbbells. Focus on chest & back hypertrophy.',
    createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
    nutritionTip:
      'Target 1.8g to 2.2g of protein per kg of bodyweight (around 150-180g daily) with complex carbs pre-workout and 8 hours of restorative sleep for optimal muscle protein synthesis.',
    originalPlan: {
      overview: 'Hypertrophy-focused 5-day push/pull/legs protocol designed to stimulate progressive overload while safeguarding joint longevity.',
      motivationalQuote: 'Discipline is doing what needs to be done, even when you do not feel like doing it.',
      nutritionTip: 'Target 1.8g to 2.2g of protein per kg of bodyweight with complex carbs pre-workout and 8 hours of restorative sleep.',
      safetyDisclaimer: 'FitBuddy provides general fitness and wellness information and is not a substitute for professional medical advice.',
      days: [
        {
          day: 1,
          focus: 'Chest & Triceps Hypertrophy',
          warmupDuration: '8 minutes',
          warmup: [
            '3 minutes light rowing machine',
            'Band pull-aparts and arm circles (2 sets of 15)',
            'Rotator cuff external rotations with light band',
          ],
          exercises: [
            { name: 'Barbell Bench Press', sets: 4, reps: '8-10 reps', rest: '90 seconds', notes: 'Maintain arched back and retracted scapulae' },
            { name: 'Incline Dumbbell Press', sets: 3, reps: '10-12 reps', rest: '75 seconds', notes: '30-degree incline for upper pectoral recruitment' },
            { name: 'Cable Chest Flyes', sets: 3, reps: '12-15 reps', rest: '60 seconds', notes: 'Squeeze at peak contraction for 1 second' },
            { name: 'Triceps Rope Pushdowns', sets: 4, reps: '12 reps', rest: '60 seconds', notes: 'Lock elbows at your sides' },
          ],
          cooldown: '5 minutes static chest opener stretch and triceps overhead stretch',
          recovery: 'Drink 750ml electrolyte water and consume a protein shake within 45 minutes.',
        },
        {
          day: 2,
          focus: 'Back & Biceps Pull Focus',
          warmupDuration: '8 minutes',
          warmup: ['5 minutes elliptical', 'Cat-cow spine mobility', 'Dead hangs from pull-up bar (2 x 30s)'],
          exercises: [
            { name: 'Barbell Bent-Over Rows', sets: 4, reps: '8-10 reps', rest: '90 seconds', notes: 'Keep spine neutral and hinge at hips' },
            { name: 'Lat Pulldowns', sets: 3, reps: '10-12 reps', rest: '75 seconds', notes: 'Drive with elbows down toward hips' },
            { name: 'Single-Arm Dumbbell Row', sets: 3, reps: '12 reps/side', rest: '60 seconds', notes: 'Full stretch at bottom' },
            { name: 'Incline Dumbbell Bicep Curls', sets: 3, reps: '12 reps', rest: '60 seconds', notes: 'Full supination at top' },
          ],
          cooldown: '5 minutes doorway lat stretch and child’s pose decompression',
          recovery: 'Foam roll thoracic spine; eat carbohydrate and protein balanced dinner.',
        },
        {
          day: 3,
          focus: 'Active Mobility & Core Recovery',
          isRestDay: true,
          warmupDuration: '5 minutes',
          warmup: ['5 minutes brisk outdoor walk', 'Gentle neck and shoulder rolls'],
          exercises: [
            { name: 'Bird-Dogs', sets: 3, reps: '10 reps/side', rest: '45 seconds', notes: 'Keep core braced and pelvis level' },
            { name: 'Side Plank Holds', sets: 3, reps: '30 seconds/side', rest: '45 seconds', notes: 'Align shoulders, hips and ankles' },
            { name: 'Deadbugs', sets: 3, reps: '12 reps/side', rest: '45 seconds', notes: 'Lower back pressed flat to ground' },
          ],
          cooldown: '10 minutes full-body yoga flow and deep diaphragmatic breathing',
          recovery: 'Focus on hydration: 3.5 liters of water throughout the day.',
        },
        {
          day: 4,
          focus: 'Legs & Calves Power',
          warmupDuration: '10 minutes',
          warmup: ['5 minutes stationary bike', 'Bodyweight squats and walking lunges', 'Ankle dorsiflexion rocks'],
          exercises: [
            { name: 'Barbell Back Squats', sets: 4, reps: '8 reps', rest: '120 seconds', notes: 'Hit parallel or deeper with controlled descent' },
            { name: 'Romanian Deadlifts (RDL)', sets: 4, reps: '10 reps', rest: '90 seconds', notes: 'Feel hamstring stretch while keeping bar close' },
            { name: 'Bulgarian Split Squats', sets: 3, reps: '10 reps/leg', rest: '75 seconds', notes: 'Front knee tracks over second toe' },
            { name: 'Standing Calf Raises', sets: 4, reps: '15 reps', rest: '45 seconds', notes: 'Pause for 2 seconds at peak stretch' },
          ],
          cooldown: '6 minutes quad, hamstring, and glute figure-4 stretches',
          recovery: 'Take an Epsom salt bath and ensure 8 hours uninterrupted sleep.',
        },
        {
          day: 5,
          focus: 'Shoulders & Arms Hypertrophy',
          warmupDuration: '7 minutes',
          warmup: ['Light shadow boxing 3 mins', 'Band dislocates and scaption raises'],
          exercises: [
            { name: 'Overhead Dumbbell Shoulder Press', sets: 4, reps: '10 reps', rest: '90 seconds', notes: 'Avoid arching lower back' },
            { name: 'Dumbbell Lateral Raises', sets: 4, reps: '12-15 reps', rest: '60 seconds', notes: 'Lead with elbows with slight forward lean' },
            { name: 'Face Pulls', sets: 3, reps: '15 reps', rest: '60 seconds', notes: 'Target rear delts and external rotators' },
            { name: 'Barbell Bicep Curls superset Skull Crushers', sets: 3, reps: '10 reps each', rest: '75 seconds', notes: 'High intensity arm finisher' },
          ],
          cooldown: '5 minutes cross-body shoulder stretch and wrist flexor stretch',
          recovery: 'High protein dinner with magnesium supplementation before bed.',
        },
        {
          day: 6,
          focus: 'Functional Conditioning & Core',
          warmupDuration: '6 minutes',
          warmup: ['Jump rope 3 minutes', 'World\'s Greatest Stretch (5 reps/side)'],
          exercises: [
            { name: 'Kettlebell Swings', sets: 4, reps: '15 reps', rest: '60 seconds', notes: 'Explosive hip drive, not a squat' },
            { name: 'Push-up to Renegade Row', sets: 3, reps: '8 reps/side', rest: '75 seconds', notes: 'Keep hips square to floor' },
            { name: 'Hanging Knee Raises', sets: 3, reps: '12 reps', rest: '60 seconds', notes: 'Avoid swinging momentum' },
          ],
          cooldown: '6 minutes cobra pose and seated spinal twist',
          recovery: 'Spend 20 minutes outdoors enjoying fresh air and sunlight.',
        },
        {
          day: 7,
          focus: 'Complete Rest & Mindful Recovery',
          isRestDay: true,
          warmupDuration: '5 minutes',
          warmup: ['Gentle morning sunshine stroll', 'Deep slow breathing'],
          exercises: [
            { name: 'Gentle Mobility Walk', sets: 1, reps: '30 minutes', rest: '0', notes: 'Easy conversational pace for blood flow' },
          ],
          cooldown: '10 minutes meditation or progressive muscle relaxation',
          recovery: 'Prepare your meal plan for the upcoming week and sleep early.',
        },
      ],
    },
  };

  const user2: UserRecord = {
    userId: 'fit-sarah-14',
    name: 'Sarah Jenkins',
    age: 34,
    weight: 68,
    goal: 'Weight Loss',
    intensity: 'Medium',
    experience: 'Beginner',
    duration: '30 minutes',
    availableDays: '4 days',
    preferences: 'Home workouts with minimal equipment (pair of 5kg dumbbells and a yoga mat).',
    createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
    feedback: 'Add more gentle yoga and reduce high-impact jumping exercises to be easy on knees.',
    nutritionTip:
      'Drink 500ml water 20 minutes before each meal, prioritize lean proteins (eggs, chicken, tofu) and fill half your plate with colorful vegetables to stay satiated.',
    originalPlan: {
      overview: 'Gentle fat-burning circuit with full-body functional movements tailored for beginner weight loss.',
      motivationalQuote: 'Small daily improvements over time lead to stunning results.',
      nutritionTip: 'Prioritize lean protein and colorful vegetables to stay satisfied on a gentle caloric deficit.',
      safetyDisclaimer: 'FitBuddy provides general fitness and wellness information and is not a substitute for professional medical advice.',
      days: [
        {
          day: 1,
          focus: 'Total Body Metabolic Ignition',
          warmupDuration: '5 minutes',
          warmup: ['Marching in place with high knees (2 mins)', 'Arm circles & gentle hip circles (3 mins)'],
          exercises: [
            { name: 'Bodyweight Squats to Chair', sets: 3, reps: '12 reps', rest: '45 seconds', notes: 'Control movement down to touch chair seat' },
            { name: 'Incline Wall or Counter Push-ups', sets: 3, reps: '10 reps', rest: '45 seconds', notes: 'Engage core tightly' },
            { name: 'Glute Bridges', sets: 3, reps: '15 reps', rest: '45 seconds', notes: 'Squeeze glutes at top for 2 seconds' },
            { name: 'Standing Knee-to-Elbow Crunches', sets: 3, reps: '12 reps/side', rest: '30 seconds', notes: 'Gentle core twist' },
          ],
          cooldown: '5 minutes seated forward fold and quad stretch',
          recovery: 'Rehydrate with 1 tall glass of water with lemon slice.',
        },
        {
          day: 2,
          focus: 'Active Rest & Walk',
          isRestDay: true,
          warmupDuration: '3 minutes',
          warmup: ['Ankle rolls and calf stretches'],
          exercises: [{ name: 'Brisk Neighborhood Walk', sets: 1, reps: '25-30 mins', rest: '0', notes: 'Maintain steady breathing pace' }],
          cooldown: '5 minutes calf and lower back stretching',
          recovery: 'Sip herbal tea and prioritize a nutritious home-cooked dinner.',
        },
        {
          day: 3,
          focus: 'Core & Upper Body Toning',
          warmupDuration: '5 minutes',
          warmup: ['Shoulder rolls and gentle torso twists', 'Cat-cow stretches on mat'],
          exercises: [
            { name: 'Dumbbell Floor Chest Press', sets: 3, reps: '12 reps', rest: '45 seconds', notes: 'Keep elbows at 45 degrees' },
            { name: 'Bent-Over Dumbbell Rows', sets: 3, reps: '12 reps', rest: '45 seconds', notes: 'Flat back, pull weights toward hip pockets' },
            { name: 'Modified Knee Plank', sets: 3, reps: '25 seconds', rest: '45 seconds', notes: 'Neutral spine, squeeze glutes' },
          ],
          cooldown: '5 minutes child’s pose and chest stretch',
          recovery: 'Enjoy a magnesium-rich snack such as pumpkin seeds or banana.',
        },
        {
          day: 4,
          focus: 'Recovery Day',
          isRestDay: true,
          warmupDuration: '5 minutes',
          warmup: ['Gentle wrist and neck mobility'],
          exercises: [{ name: 'Light House Mobility & Walking', sets: 1, reps: '20 mins', rest: '0', notes: 'Keep daily step count active' }],
          cooldown: '5 minutes gentle breathing',
          recovery: 'Aim for 8 hours of restorative sleep.',
        },
        {
          day: 5,
          focus: 'Lower Body Sculpt',
          warmupDuration: '5 minutes',
          warmup: ['High knee marches', 'Side-to-side step touches'],
          exercises: [
            { name: 'Reverse Lunges with Chair Support', sets: 3, reps: '8 reps/leg', rest: '45 seconds', notes: 'Step back smoothly without banging knee' },
            { name: 'Dumbbell Romanian Deadlifts', sets: 3, reps: '12 reps', rest: '45 seconds', notes: 'Hinge at hips, soft bend in knees' },
            { name: 'Standing Calf Raises', sets: 3, reps: '15 reps', rest: '30 seconds', notes: 'Hold wall for balance' },
          ],
          cooldown: '5 minutes hamstring stretch and quad stretch',
          recovery: 'Drink plenty of water and eat adequate protein.',
        },
        {
          day: 6,
          focus: 'Fun Low-Impact Cardio',
          warmupDuration: '5 minutes',
          warmup: ['Gentle arm swings and torso rotations'],
          exercises: [
            { name: 'Low Impact Step Jacks', sets: 3, reps: '45 seconds', rest: '30 seconds', notes: 'Step one foot out at a time without jumping' },
            { name: 'Standing Punches with Light Weights', sets: 3, reps: '45 seconds', rest: '30 seconds', notes: 'Controlled punches at shoulder height' },
          ],
          cooldown: '5 minutes standing side reach stretch',
          recovery: 'Take an easy rest evening.',
        },
        {
          day: 7,
          focus: 'Gentle Sunday Rest',
          isRestDay: true,
          warmupDuration: '5 minutes',
          warmup: ['Morning stretching in bed'],
          exercises: [{ name: 'Relaxing Park Stroll', sets: 1, reps: '20 mins', rest: '0', notes: 'Relax and unwind' }],
          cooldown: '5 minutes gentle neck rolls',
          recovery: 'Plan healthy meals for the new week ahead.',
        },
      ],
    },
    updatedPlan: {
      overview: 'Updated low-impact plan replacing jumps with flowing restorative yoga and knee-friendly sculpting exercises.',
      motivationalQuote: 'Honor your body where it is today, and it will reward you tomorrow.',
      nutritionTip: 'Stay hydrated with infused lemon water and keep meals rich in fiber and lean protein.',
      safetyDisclaimer: 'FitBuddy provides general fitness and wellness information and is not a substitute for professional medical advice.',
      days: [
        {
          day: 1,
          focus: 'Gentle Full Body & Yoga Foundation',
          warmupDuration: '6 minutes',
          warmup: ['Cat-cow flowing breath (2 mins)', 'Downward dog to plank transitions (2 mins)', 'Gentle torso twists'],
          exercises: [
            { name: 'Chair Supported Squats (Knee Friendly)', sets: 3, reps: '10 reps', rest: '45 seconds', notes: 'Zero knee impact; focus on pushing through heels' },
            { name: 'Warrior I & II Pose Holds', sets: 3, reps: '30 seconds/side', rest: '45 seconds', notes: 'Builds isometric lower body strength gently' },
            { name: 'Wall Push-ups', sets: 3, reps: '12 reps', rest: '45 seconds', notes: 'Gentle on wrists and joints' },
            { name: 'Glute Bridge Holds', sets: 3, reps: '12 reps (3s hold)', rest: '45 seconds', notes: 'Protects lower back and activates glutes' },
          ],
          cooldown: '6 minutes child\'s pose, cobra, and deep belly breathing',
          recovery: 'Drink 500ml water and relax with comfortable leg elevation.',
        },
        {
          day: 2,
          focus: 'Restorative Vinyasa & Mobility Walk',
          isRestDay: true,
          warmupDuration: '5 minutes',
          warmup: ['Gentle seated side bends and neck rolls'],
          exercises: [
            { name: 'Gentle Scenic Walk', sets: 1, reps: '25 mins', rest: '0', notes: 'Comfortable flat ground walking' },
            { name: 'Gentle Standing Hamstring Stretches', sets: 2, reps: '30 seconds', rest: '30 seconds', notes: 'No bouncing, breathe deep' },
          ],
          cooldown: '5 minutes lying spinal twist on mat',
          recovery: 'Enjoy chamomile tea and unwind early.',
        },
        {
          day: 3,
          focus: 'Low-Impact Core & Posture Toning',
          warmupDuration: '5 minutes',
          warmup: ['Standing shoulder circles', 'Gentle bird-dog prep'],
          exercises: [
            { name: 'Floor Dumbbell Chest Press', sets: 3, reps: '10 reps', rest: '45 seconds', notes: 'Controlled pace with 5kg weights' },
            { name: 'Supported Single-Arm Dumbbell Rows', sets: 3, reps: '12 reps/side', rest: '45 seconds', notes: 'Strengthens upper back for posture' },
            { name: 'Deadbugs (Knee Friendly Core)', sets: 3, reps: '10 reps/side', rest: '45 seconds', notes: 'Safe core activation without neck strain' },
          ],
          cooldown: '6 minutes seated butterfly stretch and chest stretch',
          recovery: 'Ensure balanced protein snack like Greek yogurt with berries.',
        },
        {
          day: 4,
          focus: 'Midweek Rest & Rejuvenation',
          isRestDay: true,
          warmupDuration: '3 minutes',
          warmup: ['Gentle breathing exercises'],
          exercises: [{ name: 'Easy Nature Stroll', sets: 1, reps: '20 mins', rest: '0', notes: 'Gentle step count' }],
          cooldown: '5 minutes seated meditation',
          recovery: 'Stay hydrated with at least 2.5 liters of clean water.',
        },
        {
          day: 5,
          focus: 'Knee-Friendly Lower Body & Balance',
          warmupDuration: '5 minutes',
          warmup: ['Seated ankle circles', 'Gentle glute activation bridges'],
          exercises: [
            { name: 'Romanian Deadlifts with Dumbbells', sets: 3, reps: '10 reps', rest: '45 seconds', notes: 'Hips push back, minimal knee bending' },
            { name: 'Step-to-Side Tap (No Jump)', sets: 3, reps: '12 reps/side', rest: '45 seconds', notes: 'Smooth low-impact hip mobility' },
            { name: 'Tree Pose Balance Hold', sets: 3, reps: '30 seconds/leg', rest: '30 seconds', notes: 'Improves stability and foot strength' },
          ],
          cooldown: '6 minutes lying figure-4 glute stretch',
          recovery: 'Warm shower and foam rolling on calves.',
        },
        {
          day: 6,
          focus: 'Flow Yoga & Heart Health',
          warmupDuration: '5 minutes',
          warmup: ['Sun Salutation modified gentle pace (3 rounds)'],
          exercises: [
            { name: 'Modified Sun Salutations', sets: 4, reps: 'Smooth continuous flow', rest: '45 seconds', notes: 'Flow with breath without impact' },
            { name: 'Low Impact Shadow Boxing (No Jumping)', sets: 3, reps: '45 seconds', rest: '45 seconds', notes: 'Engage core with rhythmic punches' },
          ],
          cooldown: '7 minutes Savasana (corpse pose) relaxation',
          recovery: 'Nourishing soup or high-fiber vegetable bowl.',
        },
        {
          day: 7,
          focus: 'Deep Mind-Body Recovery',
          isRestDay: true,
          warmupDuration: '5 minutes',
          warmup: ['Morning stretching in sunlight'],
          exercises: [{ name: 'Restorative Yin Yoga Stretch', sets: 1, reps: '20 mins', rest: '0', notes: 'Long, gentle holds for fascia release' }],
          cooldown: '5 minutes grateful reflection',
          recovery: 'Quality sleep and preparation for the upcoming week.',
        },
      ],
    },
  };

  return {
    [user1.userId]: user1,
    [user2.userId]: user2,
  };
}
