import { GoogleGenAI, Type } from '@google/genai';
import { UserProfileInput, WorkoutPlan, WorkoutDay } from '../src/types.js';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const planResponseSchema = {
  type: Type.OBJECT,
  properties: {
    overview: {
      type: Type.STRING,
      description: 'A 2-3 sentence motivating overview explaining how this 7-day plan aligns with their goal, experience, and duration.',
    },
    motivationalQuote: {
      type: Type.STRING,
      description: 'An inspirational fitness quote tailored to the user and goal.',
    },
    nutritionTip: {
      type: Type.STRING,
      description: 'A dedicated, practical AI Nutrition & Recovery recommendation specifically tailored to their fitness goal and body metrics.',
    },
    safetyDisclaimer: {
      type: Type.STRING,
      description: 'Must include: "FitBuddy provides general fitness and wellness information and is not a substitute for professional medical advice."',
    },
    days: {
      type: Type.ARRAY,
      description: 'Exact 7 days of structured workout plans, from Day 1 to Day 7.',
      items: {
        type: Type.OBJECT,
        properties: {
          day: { type: Type.INTEGER, description: 'Day number 1 to 7' },
          focus: { type: Type.STRING, description: 'Focus of the day, e.g. Upper Body Strength, High Intensity Interval Conditioning, Active Mobility & Rest' },
          isRestDay: { type: Type.BOOLEAN, description: 'True if active recovery or full rest day' },
          warmupDuration: { type: Type.STRING, description: 'Warm-up duration, e.g. 5–10 minutes' },
          warmup: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '2 to 4 specific dynamic warm-up drills or activation steps',
          },
          exercises: {
            type: Type.ARRAY,
            description: 'List of main workout exercises with sets, reps, rest, and form cues',
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING, description: 'Clear exercise name' },
                sets: { type: Type.INTEGER, description: 'Number of sets (e.g. 3 or 4)' },
                reps: { type: Type.STRING, description: 'Reps or duration per set (e.g. "12 reps", "8-10 reps", "45 seconds")' },
                rest: { type: Type.STRING, description: 'Rest time between sets (e.g. "60 seconds", "45 seconds")' },
                notes: { type: Type.STRING, description: 'Form cue, posture tip, or safe regression/progression' },
              },
              required: ['name', 'sets', 'reps', 'rest'],
            },
          },
          cooldown: { type: Type.STRING, description: '5–8 minutes specific cool-down stretches or breathing technique' },
          recovery: { type: Type.STRING, description: 'Specific recovery recommendation (hydration, sleep, nutrition, mobility)' },
        },
        required: ['day', 'focus', 'warmupDuration', 'warmup', 'exercises', 'cooldown', 'recovery'],
      },
    },
  },
  required: ['overview', 'motivationalQuote', 'nutritionTip', 'safetyDisclaimer', 'days'],
};

async function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function generateWorkoutPlan(profile: UserProfileInput): Promise<WorkoutPlan> {
  const prompt = `
You are FitBuddy AI, a premier elite certified fitness coach and sports nutritionist.
Create a personalized, practical, and highly engaging 7-day fitness workout plan and nutrition/recovery guide for the following user:

USER PROFILE:
- Full Name: ${profile.name}
- Age: ${profile.age} years old
- Weight: ${profile.weight} kg
- Fitness Goal: ${profile.goal}
- Workout Intensity: ${profile.intensity}
- Experience Level: ${profile.experience}
- Workout Duration: ${profile.duration}
- Available Workout Days: ${profile.availableDays}
- Preferences / Equipment / Notes: ${profile.preferences || 'None provided'}

CRITICAL GUIDELINES:
1. Safety First: This is a wellness application. Do not diagnose medical conditions. For beginners, use safe, beginner-friendly progressions. For higher intensity, ensure balanced muscle groups and avoid overtraining.
2. Structured 7-Day Plan: Generate exactly 7 days (Day 1 through Day 7). Allocate rest/active recovery days appropriately based on their available workout days (${profile.availableDays}).
3. Session Structure: Each day MUST specify:
   - Workout Focus
   - Warm-up (5–10 minutes with 2-4 dynamic movements)
   - Main Exercises (sets, reps or duration, rest periods between sets, and technique cues)
   - Cool-down (5 minutes stretching/decompression)
   - Recovery suggestion (hydration, sleep, or nutrition)
4. Nutrition & Recovery Tip: Provide a tailored, actionable nutrition and recovery tip aligned directly with the goal of "${profile.goal}".
5. Disclaimer: Include "FitBuddy provides general fitness and wellness information and is not a substitute for professional medical advice."
6. Motivational Quote: Provide an inspiring quote suitable for ${profile.name}'s journey.
`.trim();

  // Retry with exponential backoff on transient 503/429
  let lastError: any = null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are FitBuddy AI, an expert fitness trainer and nutrition coach who designs structured, realistic 7-day workout plans strictly in valid JSON matching the schema.',
          responseMimeType: 'application/json',
          responseSchema: planResponseSchema,
          temperature: 0.7,
        },
      });

      const text = response.text;
      if (text) {
        return JSON.parse(text) as WorkoutPlan;
      }
    } catch (err: any) {
      console.warn(`[FitBuddy Gemini Attempt ${attempt}] error:`, err?.message || err);
      lastError = err;
      if (attempt < 3) {
        await sleep(1500 * attempt);
      }
    }
  }

  console.warn('[FitBuddy] Gemini API unavailable or high demand. Generating tailored algorithmic plan fallback...');
  return generateIntelligentFallbackPlan(profile);
}

export async function updateWorkoutPlan(
  profile: UserProfileInput,
  originalPlan: WorkoutPlan,
  feedback: string
): Promise<WorkoutPlan> {
  const prompt = `
You are FitBuddy AI. A user has received their initial 7-day workout plan and submitted feedback to refine or modify it.

USER PROFILE:
- Name: ${profile.name}
- Age: ${profile.age}
- Weight: ${profile.weight} kg
- Goal: ${profile.goal}
- Intensity: ${profile.intensity}
- Experience: ${profile.experience}
- Duration: ${profile.duration}
- Available Days: ${profile.availableDays}
- Preferences: ${profile.preferences || 'None'}

USER FEEDBACK ON PLAN:
"${feedback}"

ORIGINAL 7-DAY PLAN OVERVIEW:
${originalPlan.overview}

DAYS SUMMARY OF ORIGINAL PLAN:
${originalPlan.days.map((d) => `Day ${d.day} (${d.focus}): ${d.exercises.map((e) => e.name).join(', ')}`).join('\n')}

INSTRUCTIONS:
1. Update and improve the 7-day plan directly addressing the user's feedback (e.g. if they asked for "more yoga", "less knee strain", "add cardio", "include extra rest days", or "adjust intensity", adapt the exercises, focuses, and volume accordingly).
2. Maintain the full 7-day structure (Day 1 through Day 7) with warmup, exercises, rest times, cooldown, and recovery for each day.
3. Update the overview to summarize the modifications made in response to their feedback.
4. Keep the safety disclaimer: "FitBuddy provides general fitness and wellness information and is not a substitute for professional medical advice."
5. Provide updated nutrition/recovery recommendations if relevant to the feedback.
`.trim();

  let lastError: any = null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are FitBuddy AI. Update the 7-day workout plan based on user feedback. Return strictly valid JSON conforming to the schema.',
          responseMimeType: 'application/json',
          responseSchema: planResponseSchema,
          temperature: 0.7,
        },
      });

      const text = response.text;
      if (text) {
        return JSON.parse(text) as WorkoutPlan;
      }
    } catch (err: any) {
      console.warn(`[FitBuddy Update Gemini Attempt ${attempt}] error:`, err?.message || err);
      lastError = err;
      if (attempt < 3) {
        await sleep(1500 * attempt);
      }
    }
  }

  console.warn('[FitBuddy] Gemini API high demand during update. Applying feedback adaptively to plan...');
  return adaptPlanWithFeedbackFallback(profile, originalPlan, feedback);
}

// Resilient intelligent fallback tailored directly to the user's metrics
function generateIntelligentFallbackPlan(p: UserProfileInput): WorkoutPlan {
  const sets = p.intensity === 'High' ? 4 : p.intensity === 'Medium' ? 3 : 2;
  const restTime = p.intensity === 'High' ? '60-75 seconds' : p.intensity === 'Medium' ? '60 seconds' : '45 seconds';
  
  const isBeginner = p.experience === 'Beginner';
  const duration = p.duration;

  let nutritionTip = '';
  let motivationalQuote = '';

  if (p.goal === 'Weight Loss') {
    motivationalQuote = 'Every small, consistent healthy choice creates a monumental transformation over time.';
    nutritionTip = `To support your target weight loss at ${p.weight}kg, maintain a moderate 300-500 kcal deficit, drink at least 2.5-3L water daily, and consume 1.6g of lean protein per kg of body weight to preserve lean muscle while burning fat.`;
  } else if (p.goal === 'Muscle Gain') {
    motivationalQuote = 'Strength does not come from what you can do. It comes from overcoming the things you once thought you could not.';
    nutritionTip = `For hypertrophy at ${p.weight}kg, target 1.8g to 2.2g of protein per kg (~${Math.round(p.weight * 2)}g daily) paired with complex carbohydrate fuel pre-workout and 7-9 hours of deep sleep to maximize muscle protein synthesis.`;
  } else if (p.goal === 'Strength') {
    motivationalQuote = 'Consistency is the foundation upon which elite strength is forged.';
    nutritionTip = `Optimize heavy compound training with adequate creatine monohydrate (3-5g daily), sufficient healthy fats for hormonal balance, and plenty of electrolyte-rich hydration during long lifting sessions.`;
  } else {
    motivationalQuote = 'Wellness is a complete harmony of physical movement, nourishing food, and restorative recovery.';
    nutritionTip = `Focus on colorful whole foods, high fiber intake, mindful hydration, and at least 30 minutes of low-stress mobility each day to optimize joint longevity and sustained energy.`;
  }

  const days: WorkoutDay[] = [
    {
      day: 1,
      focus: p.goal === 'Muscle Gain' ? 'Upper Body Power & Push' : 'Full Body Functional Conditioning',
      warmupDuration: '8 minutes',
      warmup: [
        '3 minutes jumping jacks or dynamic arm swings',
        'Scapular wall slides and band pull-aparts (2 sets of 12)',
        'Hip openers and dynamic torso rotations',
      ],
      exercises: [
        {
          name: isBeginner ? 'Dumbbell or Incline Push-ups' : 'Barbell Bench Press or Heavy Dumbbell Press',
          sets,
          reps: isBeginner ? '10-12 reps' : '8-10 reps',
          rest: restTime,
          notes: 'Keep elbows tucked at 45 degrees, chest proudly lifted.',
        },
        {
          name: isBeginner ? 'Goblet Squats with Dumbbell' : 'Barbell Back Squats',
          sets,
          reps: '10-12 reps',
          rest: restTime,
          notes: 'Drive through mid-foot and maintain an upright torso.',
        },
        {
          name: 'Single-Arm Dumbbell Rows',
          sets,
          reps: '12 reps/arm',
          rest: restTime,
          notes: 'Pull elbow toward hip pocket, pause for 1 second at top.',
        },
        {
          name: 'Forearm Plank Hold',
          sets: 3,
          reps: '30-45 seconds',
          rest: '45 seconds',
          notes: 'Engage glutes and core, keep neutral cervical spine.',
        },
      ],
      cooldown: '5 minutes chest opening stretch, cobra stretch, and deep nasal breathing',
      recovery: 'Drink 600ml water with lemon or electrolytes; consume a protein-rich meal within an hour.',
    },
    {
      day: 2,
      focus: 'Lower Body & Core Stability',
      warmupDuration: '7 minutes',
      warmup: [
        '4 minutes stationary bike or high knees march',
        'Bodyweight air squats (2 sets of 10)',
        'Ankle mobility circles and calf dynamic stretches',
      ],
      exercises: [
        {
          name: 'Romanian Deadlifts (Dumbbell or Barbell)',
          sets,
          reps: '10-12 reps',
          rest: restTime,
          notes: 'Hinge back at the hips, keeping the weight skimming close to shins.',
        },
        {
          name: isBeginner ? 'Reverse Lunges with Support' : 'Walking Lunges with Dumbbells',
          sets,
          reps: '10 reps/leg',
          rest: restTime,
          notes: 'Ensure front knee does not collapse inward.',
        },
        {
          name: 'Glute Bridges or Hip Thrusts',
          sets,
          reps: '15 reps',
          rest: '45 seconds',
          notes: 'Hard 2-second isometric squeeze at the peak.',
        },
        {
          name: 'Deadbugs Core Progression',
          sets: 3,
          reps: '10 reps/side',
          rest: '30 seconds',
          notes: 'Press lower back firmly into the floor.',
        },
      ],
      cooldown: '6 minutes quad, hamstring, and pigeon glute stretches',
      recovery: 'Post-workout foam roll on quadriceps and hamstrings; prioritize early bedtime.',
    },
    {
      day: 3,
      focus: 'Active Mobility & Cardiovascular Flush',
      isRestDay: true,
      warmupDuration: '5 minutes',
      warmup: ['Gentle neck, wrist and shoulder circles', 'Cat-cow spine waves on mat'],
      exercises: [
        {
          name: 'Brisk Low-Impact Incline Walk or Light Cycling',
          sets: 1,
          reps: '25-35 minutes',
          rest: '0 seconds',
          notes: 'Comfortable aerobic zone 2 pace allowing continuous conversation.',
        },
        {
          name: 'World’s Greatest Stretch Flow',
          sets: 2,
          reps: '5 reps/side',
          rest: '30 seconds',
          notes: 'Mobilizes thoracic spine, hip flexors, and hamstrings.',
        },
        {
          name: 'Diaphragmatic Box Breathing',
          sets: 1,
          reps: '5 minutes',
          rest: '0 seconds',
          notes: 'Inhale 4s, hold 4s, exhale 4s, hold 4s to reset central nervous system.',
        },
      ],
      cooldown: '5 minutes child’s pose and gentle seated hamstring stretch',
      recovery: 'Hydrate continuously throughout the day; aim for 3L clean water.',
    },
    {
      day: 4,
      focus: p.goal === 'Muscle Gain' ? 'Back & Biceps Pull Hypertrophy' : 'Metabolic Core & Conditioning',
      warmupDuration: '8 minutes',
      warmup: ['3 minutes rowing machine or shadow boxing', 'Band dislocates and arm circles', 'Bird-dog core activations'],
      exercises: [
        {
          name: 'Lat Pulldowns or Assisted Pull-ups',
          sets,
          reps: '10-12 reps',
          rest: restTime,
          notes: 'Lead the movement by driving elbows down toward the ribcage.',
        },
        {
          name: 'Overhead Dumbbell Shoulder Press',
          sets,
          reps: '10 reps',
          rest: restTime,
          notes: 'Brace core tightly; do not arch lumbar spine.',
        },
        {
          name: 'Dumbbell Hammer Curls',
          sets,
          reps: '12 reps',
          rest: '45 seconds',
          notes: 'Controlled eccentric lowering phase of 2-3 seconds.',
        },
        {
          name: 'Side Plank Holds',
          sets: 3,
          reps: '30 seconds/side',
          rest: '30 seconds',
          notes: 'Maintain a straight line from ankle to crown of head.',
        },
      ],
      cooldown: '5 minutes doorway chest and lat stretches',
      recovery: 'Enjoy a balanced post-workout meal with clean carbs and 30g+ protein.',
    },
    {
      day: 5,
      focus: 'Lower Body Sculpt & Athletic Power',
      warmupDuration: '8 minutes',
      warmup: ['Dynamic leg swings (front-to-back & lateral)', 'Glute bridge activations', 'Walking quad stretches'],
      exercises: [
        {
          name: isBeginner ? 'Step-Ups to Sturdy Bench' : 'Bulgarian Split Squats',
          sets,
          reps: '10 reps/side',
          rest: restTime,
          notes: 'Control the descent, feeling glute and quad engagement.',
        },
        {
          name: 'Dumbbell Sumo Squats',
          sets,
          reps: '12 reps',
          rest: restTime,
          notes: 'Wider stance with toes pointed slightly outward.',
        },
        {
          name: 'Standing Calf Raises',
          sets: 4,
          reps: '15-20 reps',
          rest: '40 seconds',
          notes: 'Full stretch at the bottom and hard 2s contraction at top.',
        },
        {
          name: 'Hanging Knee Tucks or Reverse Crunches',
          sets: 3,
          reps: '12 reps',
          rest: '45 seconds',
          notes: 'Initiate by curling hips upward, not swinging with momentum.',
        },
      ],
      cooldown: '6 minutes seated butterfly, hamstring stretch, and quad stretch',
      recovery: 'Take an Epsom salt soak or warm shower; replenish electrolytes.',
    },
    {
      day: 6,
      focus: 'High Energy Conditioning & HIIT Finisher',
      warmupDuration: '7 minutes',
      warmup: ['Light jog or jumping jacks (3 mins)', 'Torso twists and arm circles', 'Bodyweight inchworms'],
      exercises: [
        {
          name: 'Kettlebell or Dumbbell Swings',
          sets,
          reps: '15 reps',
          rest: '60 seconds',
          notes: 'Hinge explosively from the hips; arms act only as hooks.',
        },
        {
          name: isBeginner ? 'Low Impact Step Jacks' : 'Mountain Climbers',
          sets,
          reps: '40 seconds work',
          rest: '45 seconds',
          notes: 'Keep hips low and maintain steady breathing cadence.',
        },
        {
          name: 'Dumbbell Renegade Rows to Push-up',
          sets,
          reps: '8 reps/side',
          rest: '60 seconds',
          notes: 'Prevent hips from rotating while pulling.',
        },
      ],
      cooldown: '6 minutes downward dog, cobra stretch, and seated forward fold',
      recovery: 'Celebrate completing your active workout week! Eat a nutrient-dense whole food dinner.',
    },
    {
      day: 7,
      focus: 'Complete Rest & Rejuvenation',
      isRestDay: true,
      warmupDuration: '5 minutes',
      warmup: ['Morning sunlight walk and gentle breathing'],
      exercises: [
        {
          name: 'Mindful Nature Walk or Casual Bike Ride',
          sets: 1,
          reps: '20-30 minutes',
          rest: '0 seconds',
          notes: 'Unhurried, leisurely pace to promote circulation and mental clarity.',
        },
        {
          name: 'Full Body Foam Rolling & Gentle Yoga',
          sets: 1,
          reps: '15 minutes',
          rest: '0 seconds',
          notes: 'Gently release tightness in IT bands, lats, and calves.',
        },
      ],
      cooldown: '5 minutes progressive muscle relaxation or mindfulness meditation',
      recovery: 'Meal prep healthy lunches for the week ahead and prioritize 8 hours of restorative sleep.',
    },
  ];

  return {
    overview: `Customized 7-day ${p.goal} split engineered for ${p.name} with ${p.intensity.toLowerCase()} intensity across ${duration} sessions, tailored to build sustainable habits while safeguarding joint health.`,
    motivationalQuote,
    nutritionTip,
    safetyDisclaimer: 'FitBuddy provides general fitness and wellness information and is not a substitute for professional medical advice.',
    days,
  };
}

function adaptPlanWithFeedbackFallback(
  profile: UserProfileInput,
  originalPlan: WorkoutPlan,
  feedback: string
): WorkoutPlan {
  const lowerFb = feedback.toLowerCase();
  const updatedDays = originalPlan.days.map((day) => {
    const copy = { ...day, exercises: [...day.exercises], warmup: [...day.warmup] };

    // If user requested yoga or mobility
    if (lowerFb.includes('yoga') || lowerFb.includes('mobility') || lowerFb.includes('stretch')) {
      copy.cooldown = '8 minutes flowing restorative yoga (Warrior poses, Pigeon stretch, Savasana)';
      if (copy.isRestDay) {
        copy.focus = `${copy.focus} & Restorative Yoga`;
      }
    }

    // If user requested cardio
    if (lowerFb.includes('cardio') || lowerFb.includes('aerobic') || lowerFb.includes('running')) {
      copy.exercises.push({
        name: 'Cardio Interval Finisher (Jogging or Stationary Bike)',
        sets: 3,
        reps: '3 mins on / 1 min easy',
        rest: '45 seconds',
        notes: 'Target 70-80% max heart rate to boost caloric expenditure.',
      });
    }

    // If user requested joint/knee friendliness or lower intensity
    if (lowerFb.includes('knee') || lowerFb.includes('joint') || lowerFb.includes('low impact') || lowerFb.includes('reduce intensity')) {
      copy.exercises = copy.exercises.map((ex) => {
        if (ex.name.toLowerCase().includes('jump') || ex.name.toLowerCase().includes('squat')) {
          return {
            ...ex,
            name: `${ex.name} (Chair Supported / Knee Friendly)`,
            notes: 'Zero knee impact; focus on pushing through heels with slow controlled tempo.',
          };
        }
        return ex;
      });
    }

    // If user requested more rest days
    if (lowerFb.includes('rest day') && day.day === 5) {
      copy.isRestDay = true;
      copy.focus = 'Active Rest, Fascia Release & Gentle Walk';
      copy.exercises = [
        {
          name: 'Scenic Recovery Walk',
          sets: 1,
          reps: '30 minutes',
          rest: '0',
          notes: 'Low intensity recovery walk.',
        },
      ];
    }

    return copy;
  });

  return {
    overview: `Updated 7-day plan successfully modified in accordance with user feedback: "${feedback}". Rest periods, exercise variations, and session volumes have been calibrated to your exact specifications.`,
    motivationalQuote: `Listening to your body is the mark of a true champion. Keep moving forward!`,
    nutritionTip: originalPlan.nutritionTip,
    safetyDisclaimer: originalPlan.safetyDisclaimer,
    days: updatedDays,
  };
}
