# FitBuddy – AI Fitness Plan Generator

> “Your AI-powered personal fitness companion”

FitBuddy is a modern, responsive, full-stack wellness and fitness application powered by **Google Gemini AI**. It generates structured, practical 7-day workout plans, goal-aligned nutrition and recovery guidance, and allows users to dynamically update and refine their routines with AI feedback while preserving the original blueprint. An integrated Coach & Admin Dashboard enables fitness professionals to monitor registered profiles, compare plan versions, and inspect client feedback.

---

## 🚀 Key Features

1. **Fitness Profile Configuration**
   - Collects Full Name, User ID, Age, Weight (kg), Fitness Goal, Workout Intensity, Experience Level, Available Workout Days, Duration, and Preferences.
   - Built-in form validation and instant presets for testing (Muscle Gain, Low-Impact Weight Loss, General Wellness).

2. **Personalized 7-Day Workout Generation with Gemini AI**
   - Day 1 through Day 7 structured routines.
   - Each day details:
     - 🏋️ Workout Focus
     - 🔥 Dynamic Warm-up (5–10 minutes with specific drills)
     - 💪 Main Exercises (Sets, Reps / Duration, Rest Intervals, Technique & Form Cues)
     - 🧘 Dedicated Cool-down Routine
     - 💧 Post-workout Recovery & Care Guidance
     - Distinct Rest / Active Recovery Day identification.

3. **💡 AI Nutrition & Recovery Guidance**
   - Goal-specific nutrition tips (hydration benchmarks, protein distribution, sleep hygiene, and post-workout fuel) tailored to user metrics.

4. **🔄 Feedback-Driven Plan Regeneration**
   - Allows users to suggest modifications (e.g. *"Add more yoga cooldowns"*, *"Reduce intensity for sensitive knees"*, *"Add more rest days"*).
   - Gemini modifies the 7-day routine based on the original plan, user profile, and user feedback.
   - Preserves the original blueprint in database history so users can toggle and compare versions.

5. **📊 Plan History & Version Comparison**
   - Toggle between **Original Plan** and **Updated Plan**.
   - Displays exact feedback prompt and update timestamps.
   - Interactive workout completion tracker for checking off completed days.

6. **🛡️ Coach / Admin Dashboard**
   - Overview statistics: Total Users, Plans Generated, Updated Plans, and Active Users.
   - Full search by User Name or User ID.
   - Multi-attribute filters: Fitness Goal, Intensity, Experience Level.
   - Sorting by Newest, Oldest, or Goal.
   - Deep inspection modal to examine profile metrics, original vs updated plans, and user feedback.
   - Ability to delete users or load client plans directly into session.

7. **🖨️ Export, Download & Print Options**
   - Native clean print stylesheet for physical gym binder printouts.
   - One-click Download Plan as formatted Markdown (`.md`).
   - Quick plan regeneration.

8. **Safety-First Wellness Logic**
   - General wellness and fitness focus (non-diagnostic).
   - Safe regressions for beginners and joint protections.
   - Prominent medical disclaimer.

---

## 🛠️ Technology Stack

- **Frontend:** React 19, TypeScript, Tailwind CSS v4, Lucide Icons, Canvas Confetti
- **Backend:** Node.js, Express, TypeScript (`tsx`)
- **AI Engine:** Google Gemini AI (`@google/genai` TypeScript SDK with model `gemini-3.8-flash`)
- **Database / Persistence:** File-backed persistent storage (`data/fitbuddy_db.json`)
- **Bundler & Server:** Vite 8 with Express middleware integration

---

## 🤖 Gemini AI Integration

FitBuddy utilizes Google Gemini 3.8 Flash (`gemini-3.8-flash`) server-side via the `@google/genai` SDK:
- **`generateWorkoutPlan(profile)`**: Prompts Gemini with user parameters to construct a structured 7-day workout JSON conforming strictly to an OpenAPI schema (`Type.OBJECT`, `Type.ARRAY`).
- **`updateWorkoutPlan(profile, originalPlan, feedback)`**: Sends the original 7-day routine, user feedback, and profile context to generate an updated version without losing structure.
- **`generateNutritionTip(goal, weight)`**: Formulates actionable nutritional recovery guidance.
- Strict security: `GEMINI_API_KEY` is kept server-side in `process.env` and never exposed to the client.

---

## 🔐 Environment Variables

Create a `.env` file in the root directory:

```env
# GEMINI_API_KEY: Required for Gemini AI API calls
GEMINI_API_KEY="your-google-gemini-api-key"

# Port (defaults to 3000)
PORT=3000
```

---

## 📦 Setup & How to Run

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure your API key in `.env`:**
   ```bash
   cp .env.example .env
   # Add your GEMINI_API_KEY
   ```

3. **Start the development server:**
   ```bash
   npm run dev
   ```
   The app will run at `http://localhost:3000`.

4. **Build for production:**
   ```bash
   npm run build
   npm start
   ```

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/generate-workout` (alias `/generate-workout`) | Validates profile and generates 7-day plan with Gemini |
| `POST` | `/api/submit-feedback` (alias `/submit-feedback`) | Updates existing plan using feedback with Gemini |
| `GET` | `/api/users` (alias `/view-all-users`, `/users`) | Retrieves users list with search, filter, and sorting |
| `GET` | `/api/users/:user_id` | Retrieves a single user record by ID |
| `DELETE` | `/api/users/:user_id` | Deletes a user record |
| `GET` | `/api/stats` | Returns aggregate dashboard metrics |

---

## 📁 Project Structure

```
fitbuddy/
├── data/
│   └── fitbuddy_db.json         # Persistent user & plan database
├── server/
│   ├── db.ts                    # Database persistence logic
│   └── gemini.ts                # Gemini AI workout & feedback services
├── src/
│   ├── components/
│   │   ├── AdminDashboard.tsx   # Coach portal, statistics, search & filter
│   │   ├── DayCard.tsx          # 7-day workout card (warm-up, exercises, cool-down)
│   │   ├── FeedbackSection.tsx  # Feedback input with chips and update trigger
│   │   ├── FitnessForm.tsx      # Responsive profile form with validation
│   │   ├── Hero.tsx             # Brand header, features & quick presets
│   │   ├── Navbar.tsx           # Sticky navigation with tab switcher
│   │   ├── NutritionCard.tsx    # AI Nutrition & Recovery card
│   │   ├── PlanDisplay.tsx      # Plan overview, actions (print, download, feedback)
│   │   ├── PlanHistory.tsx      # Original vs Updated plan version comparison
│   │   └── UserModal.tsx        # Coach inspection modal for client records
│   ├── api.ts                   # Client HTTP API methods
│   ├── types.ts                 # TypeScript interfaces and domain schemas
│   ├── App.tsx                  # Main application orchestrator
│   ├── main.tsx                 # React DOM root
│   └── index.css                # Tailwind CSS, custom fonts & print layout
├── index.html                   # Entry HTML with metadata and web fonts
├── metadata.json                # AI Studio capabilities metadata
├── package.json                 # Dependencies and execution scripts
├── server.ts                    # Express server with Vite middleware
└── tsconfig.json                # TypeScript configuration
```

---

## ⚠️ Safety Disclaimer

> **FitBuddy provides general fitness and wellness information and is not a substitute for professional medical advice.**
> Always consult a qualified physician or healthcare provider before starting any new exercise or nutrition program, especially if you have pre-existing medical conditions, cardiovascular concerns, or musculoskeletal injuries.

---

## 🔮 Future Improvements

- Wearable device sync (Apple Health, Garmin, Fitbit) for automatic recovery score calculation.
- Video technique demonstrations with animated exercise avatars.
- Multilingual workout and nutrition instructions.
- Micro-periodization scheduling (4-week and 12-week macro-cycle planning).
