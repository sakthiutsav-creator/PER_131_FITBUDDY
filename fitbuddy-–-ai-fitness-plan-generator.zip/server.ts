import 'dotenv/config';
import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import {
  getAllUsers,
  getUserById,
  saveUserRecord,
  deleteUserRecord,
  getStats,
} from './server/db.js';
import { generateWorkoutPlan, updateWorkoutPlan } from './server/gemini.js';
import { UserProfileInput, UserRecord } from './src/types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// API: Generate workout plan
const handleGenerateWorkout = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      userId,
      name,
      age,
      weight,
      goal,
      intensity,
      experience,
      duration,
      availableDays,
      preferences,
    } = req.body as UserProfileInput;

    // Validation
    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      res.status(400).json({ error: 'Please enter a valid full name.' });
      return;
    }
    if (!userId || typeof userId !== 'string' || userId.trim().length === 0) {
      res.status(400).json({ error: 'Please provide a valid user ID.' });
      return;
    }
    const parsedAge = Number(age);
    if (isNaN(parsedAge) || parsedAge < 10 || parsedAge > 115) {
      res.status(400).json({ error: 'Please enter a realistic age between 10 and 115.' });
      return;
    }
    const parsedWeight = Number(weight);
    if (isNaN(parsedWeight) || parsedWeight < 25 || parsedWeight > 350) {
      res.status(400).json({ error: 'Please enter a valid weight between 25 kg and 350 kg.' });
      return;
    }
    if (!goal) {
      res.status(400).json({ error: 'Please select a fitness goal.' });
      return;
    }
    if (!intensity) {
      res.status(400).json({ error: 'Please select a workout intensity.' });
      return;
    }
    if (!experience) {
      res.status(400).json({ error: 'Please select your experience level.' });
      return;
    }
    if (!duration) {
      res.status(400).json({ error: 'Please select preferred workout duration.' });
      return;
    }

    const cleanUserId = userId.trim().toLowerCase().replace(/\s+/g, '-');
    const profile: UserProfileInput = {
      userId: cleanUserId,
      name: name.trim(),
      age: parsedAge,
      weight: parsedWeight,
      goal,
      intensity,
      experience,
      duration,
      availableDays: availableDays || '4-5 days',
      preferences: preferences ? preferences.trim() : '',
    };

    console.log(`[FitBuddy] Generating 7-day workout plan for ${profile.name} (${cleanUserId})...`);

    // Call Gemini AI
    const generatedPlan = await generateWorkoutPlan(profile);

    // Save to DB
    const existing = getUserById(cleanUserId);
    const userRecord: UserRecord = {
      userId: cleanUserId,
      name: profile.name,
      age: profile.age,
      weight: profile.weight,
      goal: profile.goal,
      intensity: profile.intensity,
      experience: profile.experience,
      duration: profile.duration,
      availableDays: String(profile.availableDays),
      preferences: profile.preferences || '',
      originalPlan: generatedPlan,
      nutritionTip: generatedPlan.nutritionTip,
      createdAt: existing ? existing.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      feedback: existing?.feedback,
      updatedPlan: existing?.updatedPlan,
    };

    saveUserRecord(userRecord);

    res.json({
      success: true,
      user: userRecord,
      plan: generatedPlan,
      message: 'Workout plan generated successfully!',
    });
  } catch (error: any) {
    console.error('[FitBuddy Error /generate-workout]:', error);
    res.status(500).json({
      error:
        error.message ||
        'Something went wrong while generating your plan with Gemini AI. Please try again.',
    });
  }
};

// API: Submit feedback and regenerate plan
const handleSubmitFeedback = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId, feedback } = req.body;
    if (!userId) {
      res.status(400).json({ error: 'Missing User ID.' });
      return;
    }
    if (!feedback || typeof feedback !== 'string' || feedback.trim().length === 0) {
      res.status(400).json({ error: 'Please enter feedback to improve your plan.' });
      return;
    }

    const user = getUserById(userId);
    if (!user) {
      res.status(404).json({ error: `User with ID "${userId}" not found.` });
      return;
    }

    console.log(`[FitBuddy] Updating plan for ${user.name} based on feedback: "${feedback}"...`);

    const profile: UserProfileInput = {
      userId: user.userId,
      name: user.name,
      age: user.age,
      weight: user.weight,
      goal: user.goal,
      intensity: user.intensity,
      experience: user.experience,
      duration: user.duration,
      availableDays: user.availableDays,
      preferences: user.preferences,
    };

    const updatedPlan = await updateWorkoutPlan(profile, user.originalPlan, feedback.trim());

    user.feedback = feedback.trim();
    user.updatedPlan = updatedPlan;
    user.updatedAt = new Date().toISOString();

    saveUserRecord(user);

    res.json({
      success: true,
      user,
      updatedPlan,
      message: 'Workout plan updated based on your feedback!',
    });
  } catch (error: any) {
    console.error('[FitBuddy Error /submit-feedback]:', error);
    res.status(500).json({
      error:
        error.message ||
        'Something went wrong while updating your plan with Gemini AI. Please try again.',
    });
  }
};

// API: List users with search, filter, and sort
const handleGetUsers = (req: Request, res: Response): void => {
  try {
    let users = getAllUsers();
    const { search, goal, intensity, experience, sort } = req.query;

    if (search && typeof search === 'string') {
      const q = search.toLowerCase().trim();
      users = users.filter(
        (u) =>
          u.name.toLowerCase().includes(q) || u.userId.toLowerCase().includes(q)
      );
    }

    if (goal && typeof goal === 'string' && goal !== 'All') {
      users = users.filter((u) => u.goal === goal);
    }

    if (intensity && typeof intensity === 'string' && intensity !== 'All') {
      users = users.filter((u) => u.intensity === intensity);
    }

    if (experience && typeof experience === 'string' && experience !== 'All') {
      users = users.filter((u) => u.experience === experience);
    }

    if (sort === 'oldest') {
      users.sort(
        (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      );
    } else if (sort === 'goal') {
      users.sort((a, b) => a.goal.localeCompare(b.goal));
    } else {
      // default: newest
      users.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    }

    const stats = getStats();
    res.json({ users, stats });
  } catch (error: any) {
    console.error('[FitBuddy Error /users]:', error);
    res.status(500).json({ error: 'Failed to retrieve users.' });
  }
};

// Register API Routes (both /api/* and FastAPI compatible root paths)
app.post('/api/generate-workout', handleGenerateWorkout);
app.post('/generate-workout', handleGenerateWorkout);

app.post('/api/submit-feedback', handleSubmitFeedback);
app.post('/submit-feedback', handleSubmitFeedback);

app.get('/api/users', handleGetUsers);
app.get('/users', handleGetUsers);
app.get('/view-all-users', handleGetUsers);

app.get('/api/stats', (_req: Request, res: Response) => {
  res.json({ stats: getStats() });
});

app.get('/api/users/:user_id', (req: Request, res: Response) => {
  const user = getUserById(req.params.user_id);
  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }
  res.json({ user });
});
app.get('/users/:user_id', (req: Request, res: Response) => {
  const user = getUserById(req.params.user_id);
  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }
  res.json({ user });
});

app.delete('/api/users/:user_id', (req: Request, res: Response) => {
  const deleted = deleteUserRecord(req.params.user_id);
  if (!deleted) {
    res.status(404).json({ error: 'User not found' });
    return;
  }
  res.json({ success: true, message: 'User deleted successfully' });
});
app.delete('/users/:user_id', (req: Request, res: Response) => {
  const deleted = deleteUserRecord(req.params.user_id);
  if (!deleted) {
    res.status(404).json({ error: 'User not found' });
    return;
  }
  res.json({ success: true, message: 'User deleted successfully' });
});

// Vite middleware in dev or static serving in production
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[FitBuddy] Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[FitBuddy] Failed to start server:', err);
  process.exit(1);
});
