import { UserProfileInput, UserRecord, WorkoutPlan, DashboardStats } from './types.js';

export async function generateWorkoutApi(profile: UserProfileInput): Promise<{
  success: boolean;
  user: UserRecord;
  plan: WorkoutPlan;
  message?: string;
}> {
  const res = await fetch('/api/generate-workout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(profile),
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to generate workout plan.');
  }
  return data;
}

export async function submitFeedbackApi(
  userId: string,
  feedback: string
): Promise<{
  success: boolean;
  user: UserRecord;
  updatedPlan: WorkoutPlan;
  message?: string;
}> {
  const res = await fetch('/api/submit-feedback', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, feedback }),
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to submit feedback.');
  }
  return data;
}

export async function fetchUsersApi(params?: {
  search?: string;
  goal?: string;
  intensity?: string;
  experience?: string;
  sort?: string;
}): Promise<{ users: UserRecord[]; stats: DashboardStats }> {
  const query = new URLSearchParams();
  if (params?.search) query.set('search', params.search);
  if (params?.goal) query.set('goal', params.goal);
  if (params?.intensity) query.set('intensity', params.intensity);
  if (params?.experience) query.set('experience', params.experience);
  if (params?.sort) query.set('sort', params.sort);

  const res = await fetch(`/api/users?${query.toString()}`);
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to fetch users.');
  }
  return data;
}

export async function fetchUserByIdApi(userId: string): Promise<UserRecord> {
  const res = await fetch(`/api/users/${encodeURIComponent(userId)}`);
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to fetch user record.');
  }
  return data.user;
}

export async function deleteUserApi(userId: string): Promise<boolean> {
  const res = await fetch(`/api/users/${encodeURIComponent(userId)}`, {
    method: 'DELETE',
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to delete user.');
  }
  return true;
}

export async function fetchStatsApi(): Promise<DashboardStats> {
  const res = await fetch('/api/stats');
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to fetch statistics.');
  }
  return data.stats;
}
