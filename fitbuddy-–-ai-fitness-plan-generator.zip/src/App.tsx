/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Navbar } from './components/Navbar.js';
import { Hero } from './components/Hero.js';
import { FitnessForm } from './components/FitnessForm.js';
import { PlanDisplay } from './components/PlanDisplay.js';
import { FeedbackSection } from './components/FeedbackSection.js';
import { AdminDashboard } from './components/AdminDashboard.js';
import { generateWorkoutApi, submitFeedbackApi, fetchUsersApi } from './api.js';
import {
  UserProfileInput,
  UserRecord,
  FitnessGoal,
  WorkoutIntensity,
  ExperienceLevel,
  WorkoutDuration,
} from './types.js';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'plan' | 'feedback' | 'admin'>('home');
  const [currentUser, setCurrentUser] = useState<UserRecord | null>(null);
  const [activePlanVersion, setActivePlanVersion] = useState<'original' | 'updated'>('original');

  // Form state
  const [formData, setFormData] = useState<UserProfileInput>({
    userId: 'fit-user-101',
    name: '',
    age: 26,
    weight: 70,
    goal: 'Muscle Gain' as FitnessGoal,
    intensity: 'Medium' as WorkoutIntensity,
    experience: 'Beginner' as ExperienceLevel,
    duration: '45 minutes' as WorkoutDuration,
    availableDays: '4 days',
    preferences: '',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isUpdatingFeedback, setIsUpdatingFeedback] = useState(false);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [feedbackError, setFeedbackError] = useState<string | null>(null);

  // Initialize with seed user on mount if none active so user can immediately view sample plan
  useEffect(() => {
    fetchUsersApi()
      .then((data) => {
        if (data.users.length > 0 && !currentUser) {
          // Keep a reference to first user ready
        }
      })
      .catch((err) => console.log('Init check:', err));
  }, []);

  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#14b8a6', '#06b6d4', '#f59e0b'],
      });
    } catch {
      // safe fallback if canvas is restricted
    }
  };

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const res = await generateWorkoutApi(formData);
      setCurrentUser(res.user);
      setActivePlanVersion('original');
      setActiveTab('plan');
      triggerConfetti();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      setError(err.message || 'Failed to generate workout plan. Please verify inputs and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateFeedback = async (feedbackText: string) => {
    if (!currentUser) return;
    setIsUpdatingFeedback(true);
    setFeedbackError(null);

    try {
      const res = await submitFeedbackApi(currentUser.userId, feedbackText);
      setCurrentUser(res.user);
      setActivePlanVersion('updated');
      triggerConfetti();
      // Scroll to plan view
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      setFeedbackError(err.message || 'Failed to update plan. Please try again.');
    } finally {
      setIsUpdatingFeedback(false);
    }
  };

  const handleRegenerate = async () => {
    if (!currentUser) return;
    setIsRegenerating(true);
    setError(null);

    try {
      const profile: UserProfileInput = {
        userId: currentUser.userId,
        name: currentUser.name,
        age: currentUser.age,
        weight: currentUser.weight,
        goal: currentUser.goal,
        intensity: currentUser.intensity,
        experience: currentUser.experience,
        duration: currentUser.duration,
        availableDays: currentUser.availableDays,
        preferences: currentUser.preferences,
      };

      const res = await generateWorkoutApi(profile);
      setCurrentUser(res.user);
      setActivePlanVersion('original');
      triggerConfetti();
    } catch (err: any) {
      alert(`Regeneration failed: ${err.message}`);
    } finally {
      setIsRegenerating(false);
    }
  };

  const handleSelectPreset = (presetKey: 'muscle' | 'weightloss' | 'wellness') => {
    if (presetKey === 'muscle') {
      setFormData({
        userId: `fit-marcus-${Math.floor(100 + Math.random() * 900)}`,
        name: 'Marcus Reed',
        age: 29,
        weight: 82,
        goal: 'Muscle Gain',
        intensity: 'High',
        experience: 'Intermediate',
        duration: '60 minutes',
        availableDays: '5 days',
        preferences: 'Full gym barbell & dumbbells. Prioritize chest, back, and arm hypertrophy.',
      });
    } else if (presetKey === 'weightloss') {
      setFormData({
        userId: `fit-sarah-${Math.floor(100 + Math.random() * 900)}`,
        name: 'Sarah Jenkins',
        age: 34,
        weight: 68,
        goal: 'Weight Loss',
        intensity: 'Low',
        experience: 'Beginner',
        duration: '30 minutes',
        availableDays: '4 days',
        preferences: 'Home dumbbells only (5kg). Sensitive knees so minimize high-impact jumping.',
      });
    } else {
      setFormData({
        userId: `fit-elena-${Math.floor(100 + Math.random() * 900)}`,
        name: 'Elena Rostova',
        age: 31,
        weight: 63,
        goal: 'General Wellness',
        intensity: 'Medium',
        experience: 'Beginner',
        duration: '45 minutes',
        availableDays: '4 days',
        preferences: 'Full-body balance with mobility, core stabilization, and yoga stretches.',
      });
    }

    const formEl = document.getElementById('fitness-profile-form');
    if (formEl) {
      formEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToForm = () => {
    const el = document.getElementById('fitness-profile-form');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-300">
      {/* Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {activeTab === 'home' && (
          <div className="space-y-12">
            <Hero
              onScrollToForm={handleScrollToForm}
              onSelectPreset={handleSelectPreset}
            />

            <div className="max-w-3xl mx-auto">
              <FitnessForm
                formData={formData}
                setFormData={setFormData}
                onSubmit={handleGeneratePlan}
                isLoading={isLoading}
                error={error}
              />
            </div>
          </div>
        )}

        {activeTab === 'plan' && currentUser && (
          <PlanDisplay
            user={currentUser}
            onGenerateNewPlan={() => {
              setActiveTab('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onUpdateFeedback={handleUpdateFeedback}
            isUpdatingFeedback={isUpdatingFeedback}
            feedbackError={feedbackError}
            activePlanVersion={activePlanVersion}
            setActivePlanVersion={setActivePlanVersion}
            onRegenerate={handleRegenerate}
            isRegenerating={isRegenerating}
          />
        )}

        {activeTab === 'feedback' && currentUser && (
          <div className="max-w-3xl mx-auto space-y-8 animate-fadeIn">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-white font-display">
                Refine Your Fitness Plan
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                Provide feedback to adapt exercises, pacing, rest days, or intensity with Gemini AI.
              </p>
            </div>

            <FeedbackSection
              userId={currentUser.userId}
              onUpdatePlan={handleUpdateFeedback}
              isUpdating={isUpdatingFeedback}
              error={feedbackError}
              lastFeedback={currentUser.feedback}
              hasUpdatedPlan={!!currentUser.updatedPlan}
            />

            {currentUser.updatedPlan && (
              <div className="text-center pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setActivePlanVersion('updated');
                    setActiveTab('plan');
                  }}
                  className="px-6 py-3 rounded-xl font-bold bg-emerald-500 text-slate-950 hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20"
                >
                  View Your Updated 7-Day Plan →
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'admin' && (
          <AdminDashboard
            onSelectUserForSession={(user) => {
              setCurrentUser(user);
              setActivePlanVersion(user.updatedPlan ? 'updated' : 'original');
              setActiveTab('plan');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-8 text-center text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white font-display">
              Fit<span className="text-emerald-400">Buddy</span>
            </span>
            <span>– AI Fitness Plan Generator</span>
          </div>

          <p className="text-slate-400 text-[11px] max-w-lg">
            Safety First: FitBuddy provides general fitness and wellness information and is not a substitute for professional medical advice.
          </p>

          <div className="text-slate-400">
            Powered by <strong className="text-emerald-400">Google Gemini AI</strong>
          </div>
        </div>
      </footer>
    </div>
  );
}
