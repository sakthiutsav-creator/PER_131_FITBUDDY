export type FitnessGoal =
  | 'Weight Loss'
  | 'Muscle Gain'
  | 'General Wellness'
  | 'Strength'
  | 'Flexibility'
  | 'Endurance';

export type WorkoutIntensity = 'Low' | 'Medium' | 'High';

export type ExperienceLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export type WorkoutDuration =
  | '20 minutes'
  | '30 minutes'
  | '45 minutes'
  | '60 minutes'
  | '90 minutes';

export interface UserProfileInput {
  userId: string;
  name: string;
  age: number;
  weight: number;
  goal: FitnessGoal;
  intensity: WorkoutIntensity;
  experience: ExperienceLevel;
  duration: WorkoutDuration;
  availableDays: number | string;
  preferences?: string;
}

export interface WorkoutExercise {
  name: string;
  sets: number;
  reps: string;
  rest: string;
  notes?: string;
}

export interface WorkoutDay {
  day: number;
  focus: string;
  warmupDuration: string;
  warmup: string[];
  exercises: WorkoutExercise[];
  cooldown: string;
  recovery: string;
  isRestDay?: boolean;
}

export interface WorkoutPlan {
  overview: string;
  motivationalQuote: string;
  nutritionTip: string;
  safetyDisclaimer: string;
  days: WorkoutDay[];
}

export interface UserRecord {
  userId: string;
  name: string;
  age: number;
  weight: number;
  goal: FitnessGoal;
  intensity: WorkoutIntensity;
  experience: ExperienceLevel;
  duration: WorkoutDuration;
  availableDays: string;
  preferences: string;
  originalPlan: WorkoutPlan;
  feedback?: string;
  updatedPlan?: WorkoutPlan;
  nutritionTip: string;
  createdAt: string;
  updatedAt?: string;
}

export interface DashboardStats {
  totalUsers: number;
  totalPlansGenerated: number;
  updatedPlans: number;
  activeUsers: number;
}
