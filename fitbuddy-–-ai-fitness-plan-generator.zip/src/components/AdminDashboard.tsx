import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Filter,
  ArrowUpDown,
  Sparkles,
  Eye,
  Trash2,
  Calendar,
  Activity,
  FileCheck,
  RefreshCw,
  AlertCircle,
  MessageSquare,
  Shield,
} from 'lucide-react';
import { UserRecord, DashboardStats, FitnessGoal, WorkoutIntensity, ExperienceLevel } from '../types.js';
import { fetchUsersApi, deleteUserApi } from '../api.js';
import { UserModal } from './UserModal.js';

interface AdminDashboardProps {
  onSelectUserForSession: (user: UserRecord) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onSelectUserForSession }) => {
  const [users, setUsers] = useState<UserRecord[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalPlansGenerated: 0,
    updatedPlans: 0,
    activeUsers: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Search & Filters
  const [search, setSearch] = useState('');
  const [goalFilter, setGoalFilter] = useState('All');
  const [intensityFilter, setIntensityFilter] = useState('All');
  const [experienceFilter, setExperienceFilter] = useState('All');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'goal'>('newest');

  // Modal inspection
  const [selectedUser, setSelectedUser] = useState<UserRecord | null>(null);
  const [modalTab, setModalTab] = useState<'profile' | 'original' | 'updated' | 'feedback'>('profile');

  const loadUsers = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await fetchUsersApi({
        search,
        goal: goalFilter,
        intensity: intensityFilter,
        experience: experienceFilter,
        sort: sortBy,
      });
      setUsers(data.users);
      setStats(data.stats);
    } catch (err: any) {
      setError(err.message || 'Failed to load users');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, [goalFilter, intensityFilter, experienceFilter, sortBy]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadUsers();
  };

  const handleDelete = async (userId: string) => {
    try {
      await deleteUserApi(userId);
      setUsers((prev) => prev.filter((u) => u.userId !== userId));
      setStats((prev) => ({
        ...prev,
        totalUsers: Math.max(0, prev.totalUsers - 1),
        activeUsers: Math.max(0, prev.activeUsers - 1),
      }));
    } catch (err: any) {
      alert(`Error deleting user: ${err.message}`);
    }
  };

  const openUserModal = (user: UserRecord, tab: 'profile' | 'original' | 'updated' | 'feedback') => {
    setSelectedUser(user);
    setModalTab(tab);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Top Banner */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="flex items-center justify-center w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              <Shield className="w-3.5 h-3.5" />
            </span>
            <span className="text-xs uppercase tracking-wider font-bold text-indigo-400">
              Coach & Trainer Portal
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
            Admin / Coach Dashboard
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            View registered users, inspect original vs updated AI plans, track feedback iterations, and monitor metrics.
          </p>
        </div>

        <button
          type="button"
          onClick={loadUsers}
          className="self-start sm:self-auto px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-2 transition-colors cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Data</span>
        </button>
      </div>

      {/* Dashboard Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block">
              Total Users
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-display">
              {stats.totalUsers}
            </span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-400 flex items-center justify-center shrink-0">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block">
              Plans Generated
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-display">
              {stats.totalPlansGenerated}
            </span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 flex items-center justify-center shrink-0">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block">
              Updated via Feedback
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-display">
              {stats.updatedPlans}
            </span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-md flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block">
              Active Users
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-display">
              {stats.activeUsers}
            </span>
          </div>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 shadow-md space-y-4">
        <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by User Name or User ID..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-100 placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs sm:text-sm font-bold transition-all shadow-md shadow-emerald-500/15"
          >
            Search
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-3 pt-2 text-xs">
          <div className="flex items-center gap-1.5 text-slate-400">
            <Filter className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-semibold uppercase tracking-wider text-[10px]">Filter by:</span>
          </div>

          {/* Goal Filter */}
          <select
            value={goalFilter}
            onChange={(e) => setGoalFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 text-xs focus:outline-none focus:border-emerald-500"
          >
            <option value="All">All Goals</option>
            <option value="Weight Loss">Weight Loss</option>
            <option value="Muscle Gain">Muscle Gain</option>
            <option value="General Wellness">General Wellness</option>
            <option value="Strength">Strength</option>
            <option value="Flexibility">Flexibility</option>
            <option value="Endurance">Endurance</option>
          </select>

          {/* Intensity Filter */}
          <select
            value={intensityFilter}
            onChange={(e) => setIntensityFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 text-xs focus:outline-none focus:border-emerald-500"
          >
            <option value="All">All Intensities</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>

          {/* Experience Filter */}
          <select
            value={experienceFilter}
            onChange={(e) => setExperienceFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 text-xs focus:outline-none focus:border-emerald-500"
          >
            <option value="All">All Experiences</option>
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Advanced">Advanced</option>
          </select>

          {/* Sort By */}
          <div className="flex items-center gap-1.5 ml-auto text-slate-400">
            <ArrowUpDown className="w-3.5 h-3.5 text-indigo-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="newest">Sort: Newest</option>
              <option value="oldest">Sort: Oldest</option>
              <option value="goal">Sort: Goal</option>
            </select>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-sm flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Table of Registered Users */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[11px] font-bold">
              <tr>
                <th className="py-4 px-4 sm:px-6">User ID</th>
                <th className="py-4 px-4 sm:px-6">Name</th>
                <th className="py-4 px-3">Age</th>
                <th className="py-4 px-3">Weight</th>
                <th className="py-4 px-4">Goal</th>
                <th className="py-4 px-3">Intensity</th>
                <th className="py-4 px-4">Status</th>
                <th className="py-4 px-4 sm:px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {users.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500 text-sm">
                    {isLoading ? 'Loading users...' : 'No users match the search criteria.'}
                  </td>
                </tr>
              ) : (
                users.map((u) => {
                  const hasUpdated = !!u.updatedPlan;
                  return (
                    <tr
                      key={u.userId}
                      className="hover:bg-slate-800/40 transition-colors group"
                    >
                      <td className="py-4 px-4 sm:px-6 font-mono text-xs font-semibold text-emerald-400">
                        {u.userId}
                      </td>
                      <td className="py-4 px-4 sm:px-6 font-bold text-white whitespace-nowrap">
                        {u.name}
                      </td>
                      <td className="py-4 px-3 text-slate-300">{u.age}</td>
                      <td className="py-4 px-3 text-slate-300">{u.weight} kg</td>
                      <td className="py-4 px-4">
                        <span className="px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 text-xs font-medium">
                          {u.goal}
                        </span>
                      </td>
                      <td className="py-4 px-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                            u.intensity === 'High'
                              ? 'text-rose-400 bg-rose-500/10'
                              : u.intensity === 'Medium'
                              ? 'text-amber-400 bg-amber-500/10'
                              : 'text-emerald-400 bg-emerald-500/10'
                          }`}
                        >
                          {u.intensity}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        {hasUpdated ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-300 bg-indigo-500/15 border border-indigo-500/30 px-2 py-0.5 rounded-full">
                            <Sparkles className="w-3 h-3" />
                            <span>Updated</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-400 bg-slate-800/60 border border-slate-700/60 px-2 py-0.5 rounded-full">
                            <span>Original</span>
                          </span>
                        )}
                      </td>
                      <td className="py-4 px-4 sm:px-6 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => openUserModal(u, 'profile')}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                            title="View User Profile"
                          >
                            <Eye className="w-4 h-4 text-emerald-400" />
                          </button>

                          <button
                            type="button"
                            onClick={() => openUserModal(u, 'original')}
                            className="px-2 py-1 rounded-md text-[11px] font-semibold bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
                            title="View Original Plan"
                          >
                            Plan
                          </button>

                          {hasUpdated && (
                            <button
                              type="button"
                              onClick={() => openUserModal(u, 'updated')}
                              className="px-2 py-1 rounded-md text-[11px] font-semibold bg-indigo-950 text-indigo-300 hover:bg-indigo-900 border border-indigo-800/60 transition-colors"
                              title="View Updated Plan"
                            >
                              Updated
                            </button>
                          )}

                          {u.feedback && (
                            <button
                              type="button"
                              onClick={() => openUserModal(u, 'feedback')}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                              title="View Feedback"
                            >
                              <MessageSquare className="w-4 h-4 text-amber-400" />
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`Delete user ${u.name} (${u.userId})?`)) {
                                handleDelete(u.userId);
                              }
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                            title="Delete User"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Inspect User Modal */}
      {selectedUser && (
        <UserModal
          user={selectedUser}
          initialTab={modalTab}
          onClose={() => setSelectedUser(null)}
          onSelectUserForSession={(user) => {
            onSelectUserForSession(user);
            setSelectedUser(null);
          }}
          onDeleteUser={(userId) => {
            handleDelete(userId);
            setSelectedUser(null);
          }}
        />
      )}
    </div>
  );
};
