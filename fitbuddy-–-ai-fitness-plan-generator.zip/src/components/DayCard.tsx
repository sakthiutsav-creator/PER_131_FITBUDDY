import React, { useState } from 'react';
import {
  Flame,
  Dumbbell,
  Timer,
  Moon,
  Heart,
  Droplets,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { WorkoutDay } from '../types.js';

interface DayCardProps {
  day: WorkoutDay;
  isCompleted: boolean;
  onToggleComplete: (dayNum: number) => void;
}

export const DayCard: React.FC<DayCardProps> = ({ day, isCompleted, onToggleComplete }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div
      className={`printable-card rounded-2xl border transition-all duration-200 overflow-hidden ${
        isCompleted
          ? 'bg-slate-900/40 border-emerald-500/40 shadow-sm shadow-emerald-500/10'
          : day.isRestDay
          ? 'bg-slate-900/60 border-indigo-900/40 hover:border-indigo-700/60'
          : 'bg-slate-900/80 border-slate-800 hover:border-slate-700/80'
      } shadow-lg`}
    >
      {/* Header */}
      <div className="p-4 sm:p-5 flex items-center justify-between gap-4 border-b border-slate-800/60 bg-slate-950/40">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm font-display ${
              isCompleted
                ? 'bg-emerald-500 text-slate-950'
                : day.isRestDay
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
            }`}
          >
            {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : `D${day.day}`}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs uppercase tracking-wider font-semibold text-slate-400">
                Day {day.day}
              </span>
              {day.isRestDay ? (
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                  Active Recovery / Rest
                </span>
              ) : (
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  Workout Session
                </span>
              )}
            </div>
            <h4 className="text-base sm:text-lg font-bold text-white font-display flex items-center gap-2 mt-0.5">
              <span>{day.focus}</span>
            </h4>
          </div>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            type="button"
            onClick={() => onToggleComplete(day.day)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              isCompleted
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700/60'
            }`}
            title="Mark this day complete"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isCompleted ? 'Completed' : 'Mark Done'}</span>
          </button>

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title={isExpanded ? 'Collapse' : 'Expand'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Content */}
      {isExpanded && (
        <div className="p-4 sm:p-6 space-y-6 text-sm">
          {/* Warm-Up Section */}
          <div className="bg-slate-950/50 rounded-xl p-4 border border-slate-800/70">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-2">
              <Flame className="w-4 h-4 text-amber-400" />
              <span>Warm-up ({day.warmupDuration || '5-10 minutes'})</span>
            </div>
            <ul className="space-y-1.5">
              {day.warmup.map((step, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-300 text-xs sm:text-sm">
                  <span className="text-amber-400 font-bold mt-0.5">•</span>
                  <span>{step}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Exercises Section */}
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 mb-3">
              <Dumbbell className="w-4 h-4 text-emerald-400" />
              <span>Main Workout Exercises ({day.exercises.length})</span>
            </div>

            <div className="space-y-2.5">
              {day.exercises.map((ex, exIdx) => (
                <div
                  key={exIdx}
                  className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-slate-700/80 transition-colors"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-md bg-slate-800 text-emerald-400 text-xs font-bold flex items-center justify-center shrink-0">
                        {exIdx + 1}
                      </span>
                      <span className="font-semibold text-white text-sm sm:text-base">
                        {ex.name}
                      </span>
                    </div>
                    {ex.notes && (
                      <p className="text-xs text-slate-400 pl-7 italic">
                        Tip: {ex.notes}
                      </p>
                    )}
                  </div>

                  {/* Badges for Sets, Reps, Rest */}
                  <div className="flex items-center gap-2 shrink-0 pl-7 sm:pl-0 flex-wrap">
                    <div className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-semibold flex items-center gap-1">
                      <span>{ex.sets} sets</span>
                    </div>
                    <div className="px-2.5 py-1 rounded-lg bg-teal-500/10 border border-teal-500/20 text-teal-300 text-xs font-semibold">
                      <span>{ex.reps}</span>
                    </div>
                    <div className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1">
                      <Timer className="w-3 h-3 text-slate-400" />
                      <span>{ex.rest} rest</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cool-Down & Recovery Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {/* Cool-down */}
            <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800/60">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-400 mb-1.5">
                <Heart className="w-3.5 h-3.5 text-cyan-400" />
                <span>🧘 Cool-down</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {day.cooldown}
              </p>
            </div>

            {/* Recovery */}
            <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800/60">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-400 mb-1.5">
                <Droplets className="w-3.5 h-3.5 text-teal-400" />
                <span>💧 Recovery & Care</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {day.recovery}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
