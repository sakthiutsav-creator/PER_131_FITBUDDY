import React, { useState } from 'react';
import {
  User,
  Hash,
  Calendar,
  Weight,
  Target,
  Zap,
  Award,
  Clock,
  Printer,
  Download,
  RotateCcw,
  MessageSquarePlus,
  Quote,
  ShieldCheck,
  CheckCircle2,
  CalendarDays,
  FileDown,
} from 'lucide-react';
import { UserRecord, WorkoutPlan } from '../types.js';
import { DayCard } from './DayCard.js';
import { NutritionCard } from './NutritionCard.js';
import { FeedbackSection } from './FeedbackSection.js';
import { PlanHistory } from './PlanHistory.js';

interface PlanDisplayProps {
  user: UserRecord;
  onGenerateNewPlan: () => void;
  onUpdateFeedback: (feedback: string) => Promise<void>;
  isUpdatingFeedback: boolean;
  feedbackError: string | null;
  activePlanVersion: 'original' | 'updated';
  setActivePlanVersion: (ver: 'original' | 'updated') => void;
  onRegenerate: () => void;
  isRegenerating?: boolean;
}

export const PlanDisplay: React.FC<PlanDisplayProps> = ({
  user,
  onGenerateNewPlan,
  onUpdateFeedback,
  isUpdatingFeedback,
  feedbackError,
  activePlanVersion,
  setActivePlanVersion,
  onRegenerate,
  isRegenerating,
}) => {
  const [selectedDayFilter, setSelectedDayFilter] = useState<number | 'all'>('all');
  const [completedDays, setCompletedDays] = useState<number[]>([]);

  const activePlan: WorkoutPlan =
    activePlanVersion === 'updated' && user.updatedPlan ? user.updatedPlan : user.originalPlan;

  const toggleDayComplete = (dayNum: number) => {
    setCompletedDays((prev) =>
      prev.includes(dayNum) ? prev.filter((d) => d !== dayNum) : [...prev, dayNum]
    );
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // Generate clean markdown text representation
    let md = `# FitBuddy – 7-Day Personalized Fitness Plan\n\n`;
    md += `**Generated For:** ${user.name} (ID: ${user.userId})\n`;
    md += `**Date:** ${new Date(user.createdAt).toLocaleDateString()}\n`;
    md += `**Goal:** ${user.goal} | **Intensity:** ${user.intensity} | **Experience:** ${user.experience}\n`;
    md += `**Duration:** ${user.duration} | **Available Days:** ${user.availableDays}\n`;
    if (user.preferences) md += `**Preferences / Notes:** ${user.preferences}\n`;
    md += `\n---\n\n`;
    md += `### Plan Overview\n${activePlan.overview}\n\n`;
    md += `### Motivational Quote\n> "${activePlan.motivationalQuote}"\n\n`;
    md += `### AI Nutrition & Recovery Tip\n${activePlan.nutritionTip}\n\n`;
    md += `---\n\n`;
    md += `## 7-Day Workout Routine\n\n`;

    activePlan.days.forEach((day) => {
      md += `### Day ${day.day}: ${day.focus} ${day.isRestDay ? '(Rest/Recovery)' : ''}\n`;
      md += `- **Warm-up (${day.warmupDuration}):**\n`;
      day.warmup.forEach((w) => (md += `  - ${w}\n`));
      md += `- **Main Exercises:**\n`;
      day.exercises.forEach((ex, idx) => {
        md += `  ${idx + 1}. **${ex.name}** – ${ex.sets} sets × ${ex.reps} (Rest: ${ex.rest})${
          ex.notes ? ` [Tip: ${ex.notes}]` : ''
        }\n`;
      });
      md += `- **Cool-down:** ${day.cooldown}\n`;
      md += `- **Recovery Recommendation:** ${day.recovery}\n\n`;
    });

    md += `---\n\n`;
    md += `*Disclaimer: ${activePlan.safetyDisclaimer}*\n`;

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `fitbuddy-plan-${user.userId}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const displayedDays =
    selectedDayFilter === 'all'
      ? activePlan.days
      : activePlan.days.filter((d) => d.day === selectedDayFilter);

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Top Banner with Actions */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs uppercase tracking-wider font-bold text-emerald-400">
              Active Fitness Profile
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              {activePlanVersion === 'updated' ? 'Updated Version' : 'Original Blueprint'}
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
            {user.name}’s 7-Day Fitness Plan
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Targeting <strong className="text-slate-200">{user.goal}</strong> with{' '}
            <strong className="text-slate-200">{user.intensity}</strong> intensity over{' '}
            <strong className="text-slate-200">{user.duration}</strong> sessions.
          </p>
        </div>

        {/* Action Buttons Toolbar */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 action-buttons no-print">
          <button
            type="button"
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-white border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Print a clean physical fitness booklet"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-400" />
            <span>Print Plan</span>
          </button>

          <button
            type="button"
            onClick={handleDownload}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-white border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Download Plan as formatted Markdown"
          >
            <Download className="w-3.5 h-3.5 text-teal-400" />
            <span>Download</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const el = document.getElementById('improve-plan-section');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-white border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <MessageSquarePlus className="w-3.5 h-3.5 text-cyan-400" />
            <span>Give Feedback</span>
          </button>

          <button
            type="button"
            onClick={onRegenerate}
            disabled={isRegenerating}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-white border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
            title="Generate a fresh variation with Gemini"
          >
            <RotateCcw className={`w-3.5 h-3.5 text-amber-400 ${isRegenerating ? 'animate-spin' : ''}`} />
            <span>Regenerate</span>
          </button>

          <button
            type="button"
            onClick={onGenerateNewPlan}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/20 active:scale-95 cursor-pointer"
          >
            <span>+ New Profile</span>
          </button>
        </div>
      </div>

      {/* User Profile Summary Grid */}
      <div className="printable-card rounded-2xl bg-slate-900/60 border border-slate-800 p-5 sm:p-6 shadow-md">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
          <User className="w-4 h-4 text-emerald-400" />
          <span>User Profile Metrics</span>
        </h4>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 sm:gap-4 text-xs">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">User ID</span>
            <span className="font-mono font-bold text-white text-xs mt-0.5 block truncate">
              {user.userId}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Age / Weight</span>
            <span className="font-bold text-white text-xs mt-0.5 block">
              {user.age} yrs • {user.weight} kg
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Primary Goal</span>
            <span className="font-bold text-emerald-400 text-xs mt-0.5 block truncate">
              {user.goal}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Intensity</span>
            <span className="font-bold text-amber-300 text-xs mt-0.5 block">
              {user.intensity}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Experience</span>
            <span className="font-bold text-teal-300 text-xs mt-0.5 block">
              {user.experience}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Duration</span>
            <span className="font-bold text-cyan-300 text-xs mt-0.5 block">
              {user.duration}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Schedule</span>
            <span className="font-bold text-indigo-300 text-xs mt-0.5 block truncate">
              {user.availableDays}
            </span>
          </div>
        </div>

        {user.preferences && (
          <div className="mt-3 p-3 rounded-xl bg-slate-950/40 border border-slate-800/60 text-xs text-slate-300 flex items-start gap-2">
            <span className="font-semibold text-emerald-400 shrink-0">Notes & Equipment:</span>
            <span>{user.preferences}</span>
          </div>
        )}
      </div>

      {/* Motivational Quote & Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 rounded-2xl bg-slate-900/80 border border-slate-800 p-6 flex flex-col justify-between shadow-lg">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 mb-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>7-Day Blueprint Strategy</span>
            </div>
            <p className="text-sm sm:text-base text-slate-200 leading-relaxed font-normal">
              {activePlan.overview}
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
            <span>Structured progression (Day 1 → Day 7)</span>
            <span className="font-semibold text-emerald-400">
              {completedDays.length}/7 Days Completed
            </span>
          </div>
        </div>

        {/* Motivational Quote */}
        <div className="rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/25 p-6 flex flex-col justify-between shadow-lg relative overflow-hidden">
          <Quote className="w-8 h-8 text-emerald-500/20 absolute top-4 right-4" />
          <div className="relative z-10">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 block mb-2">
              Daily Motivation
            </span>
            <blockquote className="text-sm sm:text-base font-semibold text-white italic leading-relaxed">
              “{activePlan.motivationalQuote}”
            </blockquote>
          </div>
          <div className="text-xs text-slate-400 mt-4 pt-3 border-t border-slate-800/60 font-mono">
            – FitBuddy AI Coach
          </div>
        </div>
      </div>

      {/* AI Nutrition & Recovery Tip Card */}
      <NutritionCard nutritionTip={activePlan.nutritionTip} goal={user.goal} />

      {/* Day Selector & 7-Day Plan Cards */}
      <div className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
          <div>
            <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
              Your 7-Day Fitness Plan
            </h3>
            <p className="text-xs sm:text-sm text-slate-400">
              Structured daily protocols from Day 1 to Day 7. Click any day to jump or filter.
            </p>
          </div>

          {/* Quick Filter Days Pills */}
          <div className="flex items-center gap-1.5 flex-wrap no-print">
            <button
              type="button"
              onClick={() => setSelectedDayFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                selectedDayFilter === 'all'
                  ? 'bg-emerald-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              All Days (7)
            </button>
            {activePlan.days.map((d) => (
              <button
                key={d.day}
                type="button"
                onClick={() => setSelectedDayFilter(d.day)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  selectedDayFilter === d.day
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : completedDays.includes(d.day)
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                D{d.day}
              </button>
            ))}
          </div>
        </div>

        {/* Day Cards Stack */}
        <div className="space-y-4">
          {displayedDays.map((day) => (
            <DayCard
              key={day.day}
              day={day}
              isCompleted={completedDays.includes(day.day)}
              onToggleComplete={toggleDayComplete}
            />
          ))}
        </div>
      </div>

      {/* Plan History & Version Comparison */}
      <PlanHistory
        user={user}
        activePlanType={activePlanVersion}
        setActivePlanType={setActivePlanVersion}
        completedDays={completedDays}
        onToggleComplete={toggleDayComplete}
      />

      {/* Feedback Section */}
      <FeedbackSection
        userId={user.userId}
        onUpdatePlan={onUpdateFeedback}
        isUpdating={isUpdatingFeedback}
        error={feedbackError}
        lastFeedback={user.feedback}
        hasUpdatedPlan={!!user.updatedPlan}
      />

      {/* Safety Disclaimer Footer */}
      <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 text-center">
        <p className="text-xs text-slate-400 flex items-center justify-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{activePlan.safetyDisclaimer}</span>
        </p>
      </div>
    </div>
  );
};
