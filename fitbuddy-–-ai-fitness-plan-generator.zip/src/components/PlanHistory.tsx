import React, { useState } from 'react';
import { History, Sparkles, Calendar, MessageSquare, Check, ArrowRight } from 'lucide-react';
import { UserRecord, WorkoutPlan } from '../types.js';
import { DayCard } from './DayCard.js';

interface PlanHistoryProps {
  user: UserRecord;
  activePlanType: 'original' | 'updated';
  setActivePlanType: (type: 'original' | 'updated') => void;
  completedDays: number[];
  onToggleComplete: (day: number) => void;
}

export const PlanHistory: React.FC<PlanHistoryProps> = ({
  user,
  activePlanType,
  setActivePlanType,
  completedDays,
  onToggleComplete,
}) => {
  const hasUpdate = !!user.updatedPlan;
  const currentPlan: WorkoutPlan =
    activePlanType === 'updated' && user.updatedPlan ? user.updatedPlan : user.originalPlan;

  const formatDate = (isoStr?: string) => {
    if (!isoStr) return 'N/A';
    try {
      const d = new Date(isoStr);
      return d.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoStr;
    }
  };

  return (
    <div className="space-y-6">
      {/* Plan History Header Card */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6 sm:p-7 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 mb-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white font-display">
                Plan History & Versions
              </h3>
              <p className="text-xs sm:text-sm text-slate-400">
                FitBuddy preserves your original blueprint while tailoring new iterations based on your feedback.
              </p>
            </div>
          </div>

          {/* Version Switcher Tabs */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => setActivePlanType('original')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                activePlanType === 'original'
                  ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Original Plan
            </button>

            <button
              type="button"
              disabled={!hasUpdate}
              onClick={() => setActivePlanType('updated')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                !hasUpdate
                  ? 'text-slate-600 cursor-not-allowed opacity-50'
                  : activePlanType === 'updated'
                  ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Updated Plan</span>
              {hasUpdate && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              )}
            </button>
          </div>
        </div>

        {/* Plan Metadata summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div
            onClick={() => setActivePlanType('original')}
            className={`p-4 rounded-xl border cursor-pointer transition-all ${
              activePlanType === 'original'
                ? 'bg-emerald-500/10 border-emerald-500/40 ring-1 ring-emerald-500/30'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Original Blueprint
              </span>
              <span className="text-[11px] text-slate-400">
                {formatDate(user.createdAt)}
              </span>
            </div>
            <p className="text-xs text-slate-400 line-clamp-2">
              {user.originalPlan.overview}
            </p>
          </div>

          <div
            onClick={() => hasUpdate && setActivePlanType('updated')}
            className={`p-4 rounded-xl border transition-all ${
              !hasUpdate
                ? 'bg-slate-950/30 border-slate-800/40 text-slate-500 opacity-60'
                : activePlanType === 'updated'
                ? 'bg-emerald-500/10 border-emerald-500/40 ring-1 ring-emerald-500/30 cursor-pointer'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 cursor-pointer'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Updated via Feedback</span>
              </span>
              <span className="text-[11px] text-slate-400">
                {hasUpdate ? formatDate(user.updatedAt) : 'Pending Feedback'}
              </span>
            </div>
            {hasUpdate && user.feedback ? (
              <div>
                <p className="text-xs text-emerald-300 mb-1 font-medium line-clamp-1">
                  Feedback: “{user.feedback}”
                </p>
                <p className="text-xs text-slate-400 line-clamp-2">
                  {user.updatedPlan?.overview}
                </p>
              </div>
            ) : (
              <p className="text-xs text-slate-400">
                Submit feedback below to generate an improved variation with Gemini AI.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Showing Currently Active Plan */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-white uppercase tracking-wider">
              Displaying: {activePlanType === 'updated' ? 'Updated Plan' : 'Original Plan'}
            </span>
            <span className="text-xs text-slate-400">
              ({currentPlan.days.length} Days)
            </span>
          </div>
          <span className="text-xs text-slate-400">
            {completedDays.length} of 7 days completed
          </span>
        </div>

        {/* Day cards */}
        <div className="space-y-4">
          {currentPlan.days.map((day) => (
            <DayCard
              key={day.day}
              day={day}
              isCompleted={completedDays.includes(day.day)}
              onToggleComplete={onToggleComplete}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
