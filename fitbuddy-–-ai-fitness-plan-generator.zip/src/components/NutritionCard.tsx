import React from 'react';
import { Lightbulb, Apple, Droplet, Moon, Sparkles, Check } from 'lucide-react';
import { FitnessGoal } from '../types.js';

interface NutritionCardProps {
  nutritionTip: string;
  goal: FitnessGoal;
}

export const NutritionCard: React.FC<NutritionCardProps> = ({ nutritionTip, goal }) => {
  const getGoalBadges = (goalName: FitnessGoal) => {
    switch (goalName) {
      case 'Weight Loss':
        return [
          { icon: Droplet, label: 'Optimal Hydration (2.5L+)' },
          { icon: Apple, label: 'High Satiety & Lean Protein' },
          { icon: Moon, label: '7-8h Sleep for Cortisol Balance' },
        ];
      case 'Muscle Gain':
        return [
          { icon: Apple, label: '1.8-2.2g Protein / kg' },
          { icon: Sparkles, label: 'Caloric Surplus & Carbs' },
          { icon: Moon, label: '8h Muscle Protein Synthesis' },
        ];
      case 'Strength':
        return [
          { icon: Apple, label: 'Creatine & Complex Carbs' },
          { icon: Droplet, label: 'Electrolyte Replenishment' },
          { icon: Moon, label: 'Central Nervous System Recovery' },
        ];
      case 'Flexibility':
      case 'Endurance':
      default:
        return [
          { icon: Apple, label: 'Micronutrient Dense Whole Foods' },
          { icon: Droplet, label: 'Constant Hydration' },
          { icon: Moon, label: 'Consistent Sleep Schedule' },
        ];
    }
  };

  const badges = getGoalBadges(goal);

  return (
    <div className="printable-card rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900/90 to-emerald-950/30 border border-emerald-500/30 p-5 sm:p-7 shadow-xl relative overflow-hidden">
      {/* Decorative accent background */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 blur-3xl pointer-events-none -z-10" />

      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-300 flex items-center justify-center shrink-0 shadow-sm shadow-amber-400/10">
            <Lightbulb className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
              Personalized Guidance
            </span>
            <h3 className="text-lg sm:text-xl font-bold text-white font-display flex items-center gap-2">
              <span>AI Nutrition & Recovery Tip</span>
            </h3>
          </div>
        </div>

        <span className="self-start sm:self-auto text-xs font-semibold px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
          Target: {goal}
        </span>
      </div>

      {/* Main tip content */}
      <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 mb-5">
        <p className="text-sm sm:text-base text-slate-200 leading-relaxed">
          {nutritionTip}
        </p>
      </div>

      {/* Goal Pillars Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
        {badges.map((b, idx) => {
          const Icon = b.icon;
          return (
            <div
              key={idx}
              className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/60 text-xs text-slate-300 font-medium"
            >
              <Icon className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>{b.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
