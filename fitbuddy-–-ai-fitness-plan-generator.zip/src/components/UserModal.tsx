import React, { useState } from 'react';
import { X, User, Sparkles, MessageSquare, Calendar, Trash2, CheckCircle2, History } from 'lucide-react';
import { UserRecord, WorkoutPlan } from '../types.js';
import { DayCard } from './DayCard.js';
import { NutritionCard } from './NutritionCard.js';

interface UserModalProps {
  user: UserRecord | null;
  onClose: () => void;
  onSelectUserForSession: (user: UserRecord) => void;
  onDeleteUser: (userId: string) => void;
  initialTab?: 'profile' | 'original' | 'updated' | 'feedback';
}

export const UserModal: React.FC<UserModalProps> = ({
  user,
  onClose,
  onSelectUserForSession,
  onDeleteUser,
  initialTab = 'profile',
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'original' | 'updated' | 'feedback'>(initialTab);

  if (!user) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              {user.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-bold text-white font-display">
                  {user.name}
                </h3>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {user.userId}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Created: {new Date(user.createdAt).toLocaleDateString()} • Goal: {user.goal}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onSelectUserForSession(user);
                onClose();
              }}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors"
            >
              Open in My Plan
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center px-6 border-b border-slate-800 bg-slate-950/30 gap-2 overflow-x-auto text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`py-3 px-3 border-b-2 transition-colors ${
              activeTab === 'profile'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Profile Info
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('original')}
            className={`py-3 px-3 border-b-2 transition-colors ${
              activeTab === 'original'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Original Plan (7 Days)
          </button>
          <button
            type="button"
            disabled={!user.updatedPlan}
            onClick={() => setActiveTab('updated')}
            className={`py-3 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              !user.updatedPlan
                ? 'border-transparent text-slate-600 cursor-not-allowed opacity-50'
                : activeTab === 'updated'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Updated Plan</span>
            {user.updatedPlan && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            )}
          </button>
          <button
            type="button"
            disabled={!user.feedback}
            onClick={() => setActiveTab('feedback')}
            className={`py-3 px-3 border-b-2 transition-colors ${
              !user.feedback
                ? 'border-transparent text-slate-600 cursor-not-allowed opacity-50'
                : activeTab === 'feedback'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Feedback Notes
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {activeTab === 'profile' && (
            <div className="space-y-5">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
                  <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                    Age & Weight
                  </span>
                  <div className="text-base font-bold text-white mt-1">
                    {user.age} yrs • {user.weight} kg
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
                  <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                    Fitness Goal
                  </span>
                  <div className="text-base font-bold text-emerald-400 mt-1">
                    {user.goal}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
                  <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                    Intensity & Level
                  </span>
                  <div className="text-base font-bold text-amber-300 mt-1">
                    {user.intensity} • {user.experience}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
                  <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                    Session Duration
                  </span>
                  <div className="text-base font-bold text-teal-300 mt-1">
                    {user.duration}
                  </div>
                </div>
              </div>

              {user.preferences && (
                <div className="p-4 rounded-xl bg-slate-950/50 border border-slate-800">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block mb-1">
                    Preferences & Equipment
                  </span>
                  <p className="text-sm text-slate-200">{user.preferences}</p>
                </div>
              )}

              <div className="p-4 rounded-xl bg-slate-950/50 border border-slate-800">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400 block mb-1">
                  AI Nutrition & Recovery Tip
                </span>
                <p className="text-sm text-slate-200">{user.nutritionTip}</p>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm(`Are you sure you want to delete user ${user.name} (${user.userId})?`)) {
                      onDeleteUser(user.userId);
                      onClose();
                    }
                  }}
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 border border-rose-500/30 flex items-center gap-1.5 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete User Record</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'original' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block mb-1">
                  Original Strategy Overview
                </span>
                <p className="text-sm text-slate-200">{user.originalPlan.overview}</p>
              </div>

              <div className="space-y-3">
                {user.originalPlan.days.map((d) => (
                  <DayCard
                    key={d.day}
                    day={d}
                    isCompleted={false}
                    onToggleComplete={() => {}}
                  />
                ))}
              </div>
            </div>
          )}

          {activeTab === 'updated' && user.updatedPlan && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>Feedback-Modified Strategy</span>
                </span>
                <p className="text-sm text-slate-200">{user.updatedPlan.overview}</p>
                {user.feedback && (
                  <p className="text-xs text-emerald-300 mt-2 italic">
                    Prompted by: “{user.feedback}”
                  </p>
                )}
              </div>

              <div className="space-y-3">
                {user.updatedPlan.days.map((d) => (
                  <DayCard
                    key={d.day}
                    day={d}
                    isCompleted={false}
                    onToggleComplete={() => {}}
                  />
                ))}
              </div>
            </div>
          )}

          {activeTab === 'feedback' && (
            <div className="space-y-4">
              <div className="p-5 rounded-xl bg-slate-950/60 border border-slate-800">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 mb-2">
                  <MessageSquare className="w-4 h-4" />
                  <span>User Submitted Feedback</span>
                </div>
                <p className="text-sm text-white italic bg-slate-900 p-4 rounded-lg border border-slate-800">
                  “{user.feedback || 'No feedback recorded yet.'}”
                </p>
                {user.updatedAt && (
                  <p className="text-xs text-slate-400 mt-3">
                    Applied on: {new Date(user.updatedAt).toLocaleString()}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
