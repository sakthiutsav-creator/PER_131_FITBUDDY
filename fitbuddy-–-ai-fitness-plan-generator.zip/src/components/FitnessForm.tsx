import React, { useState } from 'react';
import {
  User,
  Hash,
  Calendar,
  Weight,
  Target,
  Zap,
  Award,
  Clock,
  CalendarDays,
  FileText,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';
import {
  UserProfileInput,
  FitnessGoal,
  WorkoutIntensity,
  ExperienceLevel,
  WorkoutDuration,
} from '../types.js';

interface FitnessFormProps {
  formData: UserProfileInput;
  setFormData: React.Dispatch<React.SetStateAction<UserProfileInput>>;
  onSubmit: (e: React.FormEvent) => void;
  isLoading: boolean;
  error: string | null;
}

const FITNESS_GOALS: FitnessGoal[] = [
  'Weight Loss',
  'Muscle Gain',
  'General Wellness',
  'Strength',
  'Flexibility',
  'Endurance',
];

const INTENSITIES: WorkoutIntensity[] = ['Low', 'Medium', 'High'];

const EXPERIENCES: ExperienceLevel[] = ['Beginner', 'Intermediate', 'Advanced'];

const DURATIONS: WorkoutDuration[] = [
  '20 minutes',
  '30 minutes',
  '45 minutes',
  '60 minutes',
  '90 minutes',
];

export const FitnessForm: React.FC<FitnessFormProps> = ({
  formData,
  setFormData,
  onSubmit,
  isLoading,
  error,
}) => {
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({});

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) {
      errs.name = 'Full Name is required.';
    }
    if (!formData.userId.trim()) {
      errs.userId = 'User ID is required.';
    }
    if (!formData.age || formData.age < 12 || formData.age > 115) {
      errs.age = 'Enter a valid age between 12 and 115.';
    }
    if (!formData.weight || formData.weight < 25 || formData.weight > 350) {
      errs.weight = 'Enter a realistic weight between 25 kg and 350 kg.';
    }
    setLocalErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(e);
    }
  };

  const generateRandomUserId = () => {
    const base = formData.name ? formData.name.toLowerCase().replace(/[^a-z]/g, '') : 'fit';
    const rand = Math.floor(100 + Math.random() * 900);
    setFormData((prev) => ({ ...prev, userId: `${base ? base.slice(0, 8) : 'fit'}-${rand}` }));
  };

  return (
    <div id="fitness-profile-form" className="relative scroll-mt-24">
      {/* Glow border effect */}
      <div className="relative rounded-2xl bg-slate-900/90 border border-slate-800 shadow-2xl p-6 sm:p-8 lg:p-10 backdrop-blur-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-8 border-b border-slate-800/80">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex items-center justify-center w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <Sparkles className="w-4 h-4" />
              </span>
              <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
                Create Your Fitness Profile
              </h3>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              Provide your details so Gemini AI can calculate optimal volume, intensity, and nutrition.
            </p>
          </div>

          <button
            type="button"
            onClick={generateRandomUserId}
            className="self-start sm:self-auto text-xs font-medium text-slate-400 hover:text-emerald-400 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/60 border border-slate-700/60 hover:bg-slate-800 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Generate ID</span>
          </button>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-sm flex items-start gap-3 animate-fadeIn">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Unable to generate plan</p>
              <p className="text-red-200/90 text-xs mt-0.5">{error}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Row 1: Name and User ID */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-emerald-400" />
                <span>Full Name <span className="text-rose-400">*</span></span>
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => {
                  setFormData((prev) => ({ ...prev, name: e.target.value }));
                  if (localErrors.name) setLocalErrors((prev) => ({ ...prev, name: '' }));
                }}
                placeholder="e.g. Alex Rivera"
                className={`w-full px-4 py-3 rounded-xl bg-slate-950/80 border text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all ${
                  localErrors.name ? 'border-rose-500/80' : 'border-slate-800 focus:border-emerald-500/80'
                }`}
              />
              {localErrors.name && (
                <p className="text-xs text-rose-400 mt-1.5">{localErrors.name}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5 text-emerald-400" />
                <span>User ID <span className="text-rose-400">*</span></span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={formData.userId}
                  onChange={(e) => {
                    setFormData((prev) => ({ ...prev, userId: e.target.value }));
                    if (localErrors.userId) setLocalErrors((prev) => ({ ...prev, userId: '' }));
                  }}
                  placeholder="e.g. fit-alex-48"
                  className={`w-full px-4 py-3 rounded-xl bg-slate-950/80 border text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all font-mono text-sm ${
                    localErrors.userId ? 'border-rose-500/80' : 'border-slate-800 focus:border-emerald-500/80'
                  }`}
                />
              </div>
              {localErrors.userId && (
                <p className="text-xs text-rose-400 mt-1.5">{localErrors.userId}</p>
              )}
            </div>
          </div>

          {/* Row 2: Age and Weight */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                <span>Age (Years) <span className="text-rose-400">*</span></span>
              </label>
              <input
                type="number"
                min="12"
                max="115"
                required
                value={formData.age || ''}
                onChange={(e) => {
                  setFormData((prev) => ({ ...prev, age: parseInt(e.target.value) || 0 }));
                  if (localErrors.age) setLocalErrors((prev) => ({ ...prev, age: '' }));
                }}
                placeholder="e.g. 28"
                className={`w-full px-4 py-3 rounded-xl bg-slate-950/80 border text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all ${
                  localErrors.age ? 'border-rose-500/80' : 'border-slate-800 focus:border-emerald-500/80'
                }`}
              />
              {localErrors.age && (
                <p className="text-xs text-rose-400 mt-1.5">{localErrors.age}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
                <Weight className="w-3.5 h-3.5 text-emerald-400" />
                <span>Weight (kg) <span className="text-rose-400">*</span></span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="25"
                  max="350"
                  step="0.5"
                  required
                  value={formData.weight || ''}
                  onChange={(e) => {
                    setFormData((prev) => ({ ...prev, weight: parseFloat(e.target.value) || 0 }));
                    if (localErrors.weight) setLocalErrors((prev) => ({ ...prev, weight: '' }));
                  }}
                  placeholder="e.g. 72.5"
                  className={`w-full px-4 py-3 rounded-xl bg-slate-950/80 border text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all ${
                    localErrors.weight ? 'border-rose-500/80' : 'border-slate-800 focus:border-emerald-500/80'
                  }`}
                />
                <span className="absolute right-4 top-3.5 text-xs text-slate-500 font-medium">kg</span>
              </div>
              {localErrors.weight && (
                <p className="text-xs text-rose-400 mt-1.5">{localErrors.weight}</p>
              )}
            </div>
          </div>

          {/* Row 3: Fitness Goal & Intensity */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-emerald-400" />
                <span>Fitness Goal <span className="text-rose-400">*</span></span>
              </label>
              <select
                value={formData.goal}
                onChange={(e) => setFormData((prev) => ({ ...prev, goal: e.target.value as FitnessGoal }))}
                className="w-full px-4 py-3 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/80 transition-all"
              >
                {FITNESS_GOALS.map((goal) => (
                  <option key={goal} value={goal} className="bg-slate-900 text-slate-100">
                    {goal}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-emerald-400" />
                <span>Workout Intensity <span className="text-rose-400">*</span></span>
              </label>
              <div className="grid grid-cols-3 gap-2">
                {INTENSITIES.map((lvl) => {
                  const isSelected = formData.intensity === lvl;
                  return (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setFormData((prev) => ({ ...prev, intensity: lvl }))}
                      className={`py-2.5 px-3 rounded-xl text-xs font-semibold transition-all border text-center ${
                        isSelected
                          ? lvl === 'High'
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-sm shadow-rose-500/20'
                            : lvl === 'Medium'
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-sm shadow-amber-500/20'
                            : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-sm shadow-emerald-500/20'
                          : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
                      }`}
                    >
                      {lvl}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Row 4: Experience & Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-emerald-400" />
                <span>Experience Level <span className="text-rose-400">*</span></span>
              </label>
              <div className="grid grid-cols-3 gap-2">
                {EXPERIENCES.map((exp) => (
                  <button
                    key={exp}
                    type="button"
                    onClick={() => setFormData((prev) => ({ ...prev, experience: exp }))}
                    className={`py-2.5 px-2 rounded-xl text-xs font-semibold transition-all border text-center ${
                      formData.experience === exp
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-sm shadow-emerald-500/20'
                        : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    {exp}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-400" />
                <span>Workout Duration <span className="text-rose-400">*</span></span>
              </label>
              <select
                value={formData.duration}
                onChange={(e) => setFormData((prev) => ({ ...prev, duration: e.target.value as WorkoutDuration }))}
                className="w-full px-4 py-3 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/80 transition-all text-sm"
              >
                {DURATIONS.map((dur) => (
                  <option key={dur} value={dur} className="bg-slate-900 text-slate-100">
                    {dur}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 5: Available Days */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
              <CalendarDays className="w-3.5 h-3.5 text-emerald-400" />
              <span>Available Workout Days Per Week</span>
            </label>
            <div className="flex flex-wrap gap-2">
              {['3 days', '4 days', '5 days', '6 days', '7 days'].map((days) => {
                const isSelected = String(formData.availableDays).includes(days.charAt(0));
                return (
                  <button
                    key={days}
                    type="button"
                    onClick={() => setFormData((prev) => ({ ...prev, availableDays: days }))}
                    className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all border ${
                      isSelected
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-sm'
                        : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    {days}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Row 6: Preferences / Equipment / Limitations */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-emerald-400" />
              <span>Optional Fitness Preferences & Notes</span>
            </label>
            <textarea
              rows={2}
              value={formData.preferences || ''}
              onChange={(e) => setFormData((prev) => ({ ...prev, preferences: e.target.value }))}
              placeholder="e.g. Home dumbbells only, sensitive left knee (no jumping), prefers outdoor running or yoga finish..."
              className="w-full px-4 py-3 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/80 transition-all text-sm resize-none"
            />
          </div>

          {/* Submit Button */}
          <div className="pt-4">
            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-4 px-6 rounded-2xl font-bold text-base sm:text-lg flex items-center justify-center gap-3 shadow-xl transition-all ${
                isLoading
                  ? 'bg-slate-800 text-slate-400 cursor-wait border border-slate-700'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 shadow-emerald-500/25 hover:shadow-emerald-500/40 hover:scale-[1.01] active:scale-[0.99] cursor-pointer'
              }`}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin text-emerald-400" />
                  <span>FitBuddy AI is creating your personalized plan...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Generate My Fitness Plan</span>
                </>
              )}
            </button>

            {isLoading && (
              <div className="mt-4 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center animate-fadeIn">
                <div className="flex items-center justify-center gap-2 text-xs font-semibold text-emerald-400 mb-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>Consulting Google Gemini 3.8 Flash...</span>
                </div>
                <p className="text-[12px] text-slate-300">
                  Calibrating sets, warm-ups, rep ranges, rest intervals, and nutrition tip tailored to {formData.goal}.
                </p>
              </div>
            )}
          </div>
        </form>

        {/* Safety Disclaimer Banner */}
        <div className="mt-8 pt-6 border-t border-slate-800/60 text-center">
          <p className="text-[11px] text-slate-300 flex items-center justify-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            <span>
              <strong>Safety Disclaimer:</strong> FitBuddy provides general fitness and wellness information and is not a substitute for professional medical advice.
            </span>
          </p>
        </div>
      </div>
    </div>
  );
};
