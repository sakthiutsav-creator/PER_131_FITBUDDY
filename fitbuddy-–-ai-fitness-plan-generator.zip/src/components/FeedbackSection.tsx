import React, { useState } from 'react';
import { MessageSquarePlus, Sparkles, RefreshCw, Send, AlertCircle, CheckCircle2 } from 'lucide-react';

interface FeedbackSectionProps {
  userId: string;
  onUpdatePlan: (feedback: string) => Promise<void>;
  isUpdating: boolean;
  error: string | null;
  lastFeedback?: string;
  hasUpdatedPlan?: boolean;
}

export const FeedbackSection: React.FC<FeedbackSectionProps> = ({
  userId,
  onUpdatePlan,
  isUpdating,
  error,
  lastFeedback,
  hasUpdatedPlan,
}) => {
  const [feedbackText, setFeedbackText] = useState('');
  const [localError, setLocalError] = useState('');

  const suggestions = [
    'Add more yoga & gentle mobility cooldowns',
    'Reduce workout intensity for sensitive joints',
    'Include an additional active recovery day',
    'Add more high-intensity cardio intervals',
    'Focus primarily on dumbbell-only variations',
    'Add core-strengthening exercises at the end of each workout',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackText.trim()) {
      setLocalError('Please enter your suggestions or feedback to improve your plan.');
      return;
    }
    setLocalError('');
    await onUpdatePlan(feedbackText.trim());
    setFeedbackText('');
  };

  const applySuggestion = (text: string) => {
    setFeedbackText(text);
    setLocalError('');
  };

  return (
    <div id="improve-plan-section" className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 mb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <MessageSquarePlus className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white font-display">
              Improve My Plan
            </h3>
            <p className="text-xs sm:text-sm text-slate-400">
              Not completely satisfied or want to adjust exercises? Tell Gemini AI how to adapt your plan.
            </p>
          </div>
        </div>

        {hasUpdatedPlan && (
          <span className="self-start sm:self-auto text-xs font-semibold px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Updated Plan Active</span>
          </span>
        )}
      </div>

      {(error || localError) && (
        <div className="mb-5 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs sm:text-sm flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <span>{error || localError}</span>
        </div>
      )}

      {lastFeedback && (
        <div className="mb-5 p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300">
          <span className="font-semibold text-emerald-400">Previous Feedback Applied: </span>
          <span className="italic">“{lastFeedback}”</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
            What would you like to modify?
          </label>
          <textarea
            rows={3}
            value={feedbackText}
            onChange={(e) => {
              setFeedbackText(e.target.value);
              if (localError) setLocalError('');
            }}
            placeholder="Example: Add more cardio, reduce workout intensity, include more rest days, add yoga, replace bar squats with goblet squats..."
            className="w-full px-4 py-3 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/80 transition-all text-sm resize-none"
          />
        </div>

        {/* Quick Suggestion Chips */}
        <div>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-2">
            💡 Quick Feedback Ideas:
          </span>
          <div className="flex flex-wrap gap-2">
            {suggestions.map((sug, i) => (
              <button
                key={i}
                type="button"
                onClick={() => applySuggestion(sug)}
                className="text-xs px-2.5 py-1 rounded-lg bg-slate-950/60 text-slate-300 border border-slate-800 hover:border-emerald-500/40 hover:text-emerald-300 transition-colors text-left"
              >
                + {sug}
              </button>
            ))}
          </div>
        </div>

        {/* Submit */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isUpdating}
            className={`w-full sm:w-auto px-6 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
              isUpdating
                ? 'bg-slate-800 text-slate-400 cursor-wait border border-slate-700'
                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20 active:scale-95 cursor-pointer'
            }`}
          >
            {isUpdating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
                <span>FitBuddy AI is updating your workout plan...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Update My Plan</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
