import React from 'react';
import { Sparkles, Dumbbell, ShieldCheck, Flame, HeartPulse, ArrowDown } from 'lucide-react';

interface HeroProps {
  onScrollToForm: () => void;
  onSelectPreset: (presetKey: 'muscle' | 'weightloss' | 'wellness') => void;
}

export const Hero: React.FC<HeroProps> = ({ onScrollToForm, onSelectPreset }) => {
  return (
    <section className="relative overflow-hidden py-10 md:py-16">
      {/* Background glow effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[500px] h-[300px] bg-emerald-500/10 blur-[120px] rounded-full pointer-events-none -z-10" />
      <div className="absolute top-10 right-10 w-72 h-72 bg-teal-500/10 blur-[100px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Top pill badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-emerald-500/30 text-emerald-400 text-xs sm:text-sm font-medium mb-6 shadow-inner">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
          <span>Powered by Google Gemini AI 3.8</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span className="text-slate-300">Safety-First Fitness</span>
        </div>

        {/* Brand Display */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white font-display mb-4">
          Fit<span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">Buddy</span>
        </h1>
        <p className="text-lg sm:text-2xl font-semibold text-emerald-400 tracking-wide font-display mb-3">
          AI Fitness Plan Generator
        </p>
        <p className="text-base sm:text-xl text-slate-300 font-normal max-w-2xl mx-auto mb-8 leading-relaxed">
          “Your AI-powered personal fitness companion”
        </p>

        {/* Headline & Subhead */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-6 sm:p-8 backdrop-blur-sm max-w-3xl mx-auto mb-8 shadow-xl">
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2 font-display">
            Build Better Habits With AI
          </h2>
          <p className="text-sm sm:text-base text-slate-400 max-w-xl mx-auto">
            Get a personalized 7-day workout plan powered by Google Gemini, tailored precisely to your body, goals, intensity, schedule, and recovery needs.
          </p>

          {/* Quick preset selector for instant testing */}
          <div className="mt-6 pt-6 border-t border-slate-800/60">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-3">
              ⚡ Instant Profile Presets for Testing
            </span>
            <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
              <button
                type="button"
                onClick={() => onSelectPreset('muscle')}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800/90 text-slate-200 hover:bg-emerald-500/20 hover:text-emerald-300 hover:border-emerald-500/40 border border-slate-700/60 transition-all flex items-center gap-1.5"
              >
                <Dumbbell className="w-3.5 h-3.5 text-emerald-400" />
                Muscle Gain (Hypertrophy)
              </button>
              <button
                type="button"
                onClick={() => onSelectPreset('weightloss')}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800/90 text-slate-200 hover:bg-teal-500/20 hover:text-teal-300 hover:border-teal-500/40 border border-slate-700/60 transition-all flex items-center gap-1.5"
              >
                <Flame className="w-3.5 h-3.5 text-teal-400" />
                Weight Loss (Low Impact)
              </button>
              <button
                type="button"
                onClick={() => onSelectPreset('wellness')}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800/90 text-slate-200 hover:bg-cyan-500/20 hover:text-cyan-300 hover:border-cyan-500/40 border border-slate-700/60 transition-all flex items-center gap-1.5"
              >
                <HeartPulse className="w-3.5 h-3.5 text-cyan-400" />
                General Wellness (Full-Body)
              </button>
            </div>
          </div>
        </div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 max-w-4xl mx-auto text-left mb-8">
          <div className="p-3.5 sm:p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div className="text-xl mb-1">🏋️</div>
            <div className="text-xs font-bold text-white uppercase tracking-wider">7-Day Splits</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Warmups, exercises, sets, reps & cooldowns</div>
          </div>
          <div className="p-3.5 sm:p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div className="text-xl mb-1">💡</div>
            <div className="text-xs font-bold text-white uppercase tracking-wider">AI Nutrition Tip</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Hydration, protein & recovery tailored to goals</div>
          </div>
          <div className="p-3.5 sm:p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div className="text-xl mb-1">🔄</div>
            <div className="text-xs font-bold text-white uppercase tracking-wider">Adaptive Feedback</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Refine plan with AI without losing original</div>
          </div>
          <div className="p-3.5 sm:p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div className="text-xl mb-1">🛡️</div>
            <div className="text-xs font-bold text-white uppercase tracking-wider">Coach Dashboard</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Inspect user records, history & statistics</div>
          </div>
        </div>

        {/* Scroll CTA */}
        <button
          type="button"
          onClick={onScrollToForm}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-emerald-400 transition-colors uppercase tracking-widest group"
        >
          <span>Fill Your Fitness Profile Below</span>
          <ArrowDown className="w-3.5 h-3.5 group-hover:translate-y-1 transition-transform" />
        </button>
      </div>
    </section>
  );
};
