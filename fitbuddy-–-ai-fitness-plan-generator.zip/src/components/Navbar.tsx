import React from 'react';
import { Dumbbell, Sparkles, LayoutDashboard, Calendar, MessageSquarePlus, Activity } from 'lucide-react';
import { UserRecord } from '../types.js';

interface NavbarProps {
  activeTab: 'home' | 'plan' | 'feedback' | 'admin';
  setActiveTab: (tab: 'home' | 'plan' | 'feedback' | 'admin') => void;
  currentUser: UserRecord | null;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, currentUser }) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/85 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Brand */}
          <div
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 text-slate-950 shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform duration-200">
              <Dumbbell className="w-5 h-5 font-bold" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-amber-400 rounded-full border-2 border-slate-950 flex items-center justify-center">
                <Sparkles className="w-1.5 h-1.5 text-slate-950" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-bold tracking-tight text-white font-display">
                  Fit<span className="text-emerald-400">Buddy</span>
                </span>
                <span className="hidden sm:inline-flex text-[10px] uppercase tracking-wider font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  AI Generator
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden md:block">
                Your AI-powered personal fitness companion
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveTab('home')}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'home'
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>Home</span>
            </button>

            <button
              onClick={() => setActiveTab('plan')}
              disabled={!currentUser}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                !currentUser
                  ? 'text-slate-600 cursor-not-allowed opacity-50'
                  : activeTab === 'plan'
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
              title={!currentUser ? 'Generate a plan first' : 'View your 7-day plan'}
            >
              <Calendar className="w-4 h-4" />
              <span className="relative">
                My Plan
                {currentUser && (
                  <span className="absolute -top-1 -right-2 w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('feedback')}
              disabled={!currentUser}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                !currentUser
                  ? 'text-slate-600 cursor-not-allowed opacity-50'
                  : activeTab === 'feedback'
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
              title={!currentUser ? 'Generate a plan first' : 'Refine or improve plan with feedback'}
            >
              <MessageSquarePlus className="w-4 h-4" />
              <span>Feedback</span>
            </button>

            <button
              onClick={() => setActiveTab('admin')}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'admin'
                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span className="hidden sm:inline">Coach Dashboard</span>
              <span className="sm:hidden">Coach</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};
